
package vegas.ev;

import vegas.*;

class MessageCreator {


	static String createErrorMessage( String txt ) {

		return "server&err_msg&" + txt;
	}


	static String createRoundStartMessage() {

		Database db = Application.db;

		String sub1 = "";
		for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {
			sub1 += "," + db.playerNames[ pn ];
		}
		sub1 = "&" + sub1.substring( 1 );

		String sub2 = "";
		for( int cn = Database.CASINO_1; cn <= Database.CASINO_6; cn ++ ) {
			String sub3 = "";
			for( int m = 0; m < Database.MAX_NUM_MONEYS; m ++ ) {
				if( db.moneyStates[ cn ][ m ] == 0 ) {
					break;
				}
				sub3 += "," + db.moneyStates[ cn ][ m ];
			}
			sub2 += "@" + sub3.substring( 1 ); 
		}
		sub2 = "&" + sub2.substring( 1 );

		return "server&round_start" + sub1 + sub2;
	}


	static String createTurnMessage() {

		Database db = Application.db;

		return "server&turn&" + db.playerNames[ db.curTurn ];
	}


	static String createRollMessage() {

		Database db = Application.db;

		return db.playerNames[ db.curTurn ] + "&roll";
	}


	static String createRollResultMessage() {

		Database db = Application.db;

		String msg1 = "server&roll_result&" + db.playerNames[ db.curTurn ] + "@";
		String msg2 = "";

		for( int i = 0; i < Database.MAX_NUM_DICES; i ++ ) {
			if( db.rollResults[ i ] == 0 ) {
				break;
			}
			else {
				msg2 += "," + db.rollResults[ i ];
			}
		}

		return msg1 + msg2.substring( 1 );
	}


	static String createBatMessage() {

		Database db = Application.db;

		return db.playerNames[ db.curTurn ] + "&bat&" + db.bat;
	}


	static String createRoundResultEasyMessage() {

		Database db = Application.db;

		String msg1 = "server&round_result&";
		String msg2 = "";

		for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {
			msg2 += "@" + db.playerNames[ pn ] + "," + db.earnMoneys[ db.curRound - 1 ][ pn ];
		}

		return msg1 + msg2.substring( 1 );
	}


	static String createRoundResultNormalMessage() {

		Database db = Application.db;

		String msg1 = "server&round_result&";
		String msg2 = "";

		for( int cn = Database.CASINO_1; cn <= Database.CASINO_6; cn ++ ) {
			String msg3 = "@" + ( cn + 1 );
			while( true ) {

				int max = 0;
				int maxIdx = -1;

				for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {
					if( max < db.casinoEarnMoneys[ cn ][ pn ] ) {
						max = db.casinoEarnMoneys[ cn ][ pn ];
						maxIdx = pn;
					}
				}

				if( maxIdx == -1 ) { break; }

				msg3 += "," + db.playerNames[ maxIdx ];
				db.casinoEarnMoneys[ cn ][ maxIdx ] = 0;
			}

			if( msg3.length() == 2 ) {
				msg3 += ",none";
			}

			msg2 += msg3;
		}

		return msg1 + msg2.substring( 1 );
	}


	static String createRoundResultHardMessage() {

		return "server&round_result&empty";
	}
	
	
	static String createGameFinishMessage() {
	
		return "server&game_finish";
	}
}
