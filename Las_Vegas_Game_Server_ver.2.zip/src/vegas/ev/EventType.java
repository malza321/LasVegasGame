
package vegas.ev;

public enum EventType {

	OPEN_SERVER,
	CLOSE_SERVER,
	ACCEPT_CLIENT,
	BAN_CLIENT,
	RECEIVE_MESSAGE
}
