
package vegas.ev;

import java.io.*;
import vegas.*;

class Transmitter {

	static void unicast( int pn, String line ) throws Exception {

		Database db = Application.db;

		if( db.isPlayerBots[ pn ] ) {
			return;
		}

		BufferedWriter writer = db.writers[ pn ];
		writer.write( line + "\n" );
		writer.flush();
	}
}
