
package vegas.ev.lis;

import vegas.*;
import vegas.ev.*;
import vegas.gui.*;

public class ClickPlayerListener implements VegasListener {

	private final int playerNum;

	public ClickPlayerListener( int playerNum ) {

		this.playerNum = playerNum;
	}

	@Override
	public void action() {

		Database db = Application.db;
		VegasFrame frame = db.frame;
		if( db.isPlayerBots[ playerNum ] ) {
			frame.showBanConfirmPanel( 1500, "봇은 강퇴시킬 수 없습니다!" );
		}
		else if( EventProcessor.disableButtons ) {
			frame.showBanConfirmPanel( 1500, "지금 강퇴시킬 수 없습니다!" );
		} 
		else if( db.playerNames[ playerNum ] != null ) {
			String pName = db.playerNames[ playerNum ];
			frame.showBanConfirmPanel( 3000, "플레이어 \"" + pName + "\" 님을 강퇴시킵니까?", playerNum );
		}
	}
}
