
package vegas.ev.lis;

import vegas.*;
import vegas.ev.*;
import vegas.gui.*;

public class BanPlayerListener implements VegasListener {

	private final int playerNum;

	public BanPlayerListener( int playerNum ) {

		this.playerNum = playerNum;
	}

	@Override
	public void action() {

		Database db = Application.db;
		VegasFrame frame = db.frame;

		if( db.isPlayerBots[ playerNum ] ) {
			frame.showBanConfirmPanel( 1500, "봇은 강퇴시킬 수 없습니다!" );
		}
		else if( EventProcessor.disableButtons ) {
			frame.showBanConfirmPanel( 1500, "지금 강퇴시킬 수 없습니다!" );
		}
		else {
			String pName = db.playerNames[ playerNum ];
			frame.showBanConfirmPanel( 1500, "플레이어 \"" + pName + "\" 님을 강퇴시켰습니다!" );
			new Thread() { // 임시 쓰레드

				@Override
				public void run() {
					EventProcessor.process( EventType.BAN_CLIENT, playerNum );
				}

			}.start();
		}
	}
}
