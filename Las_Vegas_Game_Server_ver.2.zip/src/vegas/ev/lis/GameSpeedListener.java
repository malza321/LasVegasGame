
package vegas.ev.lis;

import vegas.*;
import vegas.gui.*;

public class GameSpeedListener implements VegasListener {

	@Override
	public void action() {

		Database db = Application.db;
		VegasFrame frame = db.frame;

		if( db.speed == 5 ) {
			db.speed = 0;
		}
		else {
			db.speed ++;
		}

		if( db.speed == 5 ) {
			frame.logNewLine( "game speed: " + db.speed + " ( fastest )" );
		}
		else {
			frame.logNewLine( "game speed: " + db.speed );
		}
	}
}
