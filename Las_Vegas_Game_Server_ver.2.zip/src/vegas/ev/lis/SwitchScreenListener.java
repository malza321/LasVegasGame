
package vegas.ev.lis;

import vegas.*;
import vegas.gui.*;

public class SwitchScreenListener implements VegasListener {

	@Override
	public void action() {

		Application.db.frame.setScreen( !Application.db.frame.getScreen() );
	}
}
