
package vegas.ev.lis;

import vegas.*;
import vegas.ev.*;
import vegas.gui.*;

public class OpenCloseServerListener implements VegasListener {

	@Override
	public void action() {

		Database db = Application.db;
		VegasFrame frame = db.frame;

		if( db.serverOpened ) {
			if( EventProcessor.disableButtons ) {
				EventProcessor.closeServer = true;
				frame.logNewLine( "wait for close server..." );
			}
			else {
				EventProcessor.process( EventType.CLOSE_SERVER, null );
			}
		}
		else {
			if( EventProcessor.disableButtons ) {
				frame.logNewLine( "you cannont open server now" );
			}
			else {
				EventProcessor.process( EventType.OPEN_SERVER, null );
			}
		}
	}
}
