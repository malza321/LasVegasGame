
package vegas.ev.lis;

import vegas.*;
import vegas.gui.*;

public class ClearLogListener implements VegasListener {

	@Override
	public void action() {

		Database db = Application.db;
		VegasFrame frame = db.frame;

		frame.logClearLines();
	}
}
