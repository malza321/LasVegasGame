
package vegas.ev;

import vegas.*;

class MessageParser {

	// 파서 모음
	// line != null 이라고 가정

	static Object[] parseNameRankMessage( String line ) throws Exception {

		Object[] values = new Object[ 2 ];

		line = line.toLowerCase();
		String[] parts = line.split( " /" );

		if( parts.length == 1 ) {

			// 이름
			String name = parts[ 0 ];
			if( !NameValidator.validate( name ) ) {
				throw new Exception( "사용할 수 없는 이름입니다." );
			}
			values[ 0 ] = name;

			// 난이도 ( 디폴트 )
			values[ 1 ] = Database.DIFF_EASY;
		}
		else if( parts.length == 2 ) {

			// 이름
			String name = parts[ 0 ];
			if( !NameValidator.validate( name ) ) {
				throw new Exception( "사용할 수 없는 이름입니다." );
			}
			values[ 0 ] = name;

			// 난이도
			if( parts[ 1 ].equals( "easy" ) ) {
				values[ 1 ] = Database.DIFF_EASY;
			}
			else if( parts[ 1 ].equals( "normal" ) ) {
				values[ 1 ] = Database.DIFF_NORMAL;
			}
			else if( parts[ 1 ].equals( "hard" ) ) {
				values[ 1 ] = Database.DIFF_HARD;
			}
			else { throw new Exception( "알 수 없는 메시지 형식입니다." ); }
		}
		else { throw new Exception( "알 수 없는 메시지 형식입니다." ); }

		return values;
	}

	static void parseStartGameMessage( String line ) throws Exception {

		line = line.toLowerCase();
		if( !line.equals( "start_game" ) ) {
			throw new Exception( "알 수 없는 메시지 형식입니다." );
		}
	}

	static void parseRollMessage( String line ) throws Exception {

		line = line.toLowerCase();
		if( !line.equals( "roll" ) ) {
			throw new Exception( "알 수 없는 메시지 형식입니다." );
		}
	}

	static void parseBatMessage( String line ) throws Exception {

		line = line.toLowerCase();

		Database db = Application.db;
		db.bat = -1;
		try { db.bat = Integer.parseInt( line ); }
		catch( Exception ex ) {}

		if( db.bat < 1 || 6 < db.bat ) {
			throw new Exception( "알 수 없는 메시지 형식입니다." );
		}

		boolean exist = false;
		for( int i = 0; i < Database.MAX_NUM_DICES; i ++ ) {
			if( db.rollResults[ i ] == db.bat ) {
				exist = true;
				break;
			}
		}

		if( !exist ) {
			throw new Exception( "주사위 결과에 존재하지 않는 숫자입니다." );
		}
	}
}
