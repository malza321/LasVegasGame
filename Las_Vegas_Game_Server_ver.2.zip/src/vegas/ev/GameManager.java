
package vegas.ev;

import vegas.*;
import vegas.gui.*;

class GameManager {


	// 봇 배팅
	static int getBotBatting() {

		Database db = Application.db;

		int[] diceCounts = new int[ 6 ];
		for( int i = 0; i < Database.MAX_NUM_DICES; i ++ ) {
			if( db.rollResults[ i ] > 0 ) {
				diceCounts[ db.rollResults[ i ] - 1 ] ++;
			}
		}

		int maxCount = 0;
		int maxCountIdx = 0;
		for( int i = 0; i < 6; i ++ ) {
			if( maxCount < diceCounts[ i ] ) {
				maxCount = diceCounts[ i ];
				maxCountIdx = i;
			}
		}

		try { Thread.sleep( ( 5 - db.speed ) * 500 ); }
		catch( Exception ex ) {}

		return maxCountIdx + 1;
	}


	// 게임 시작하기
	static void startGame() {

		Database db = Application.db;
		VegasFrame frame = db.frame;


		// 봇 확인
		if( db.numNames != Database.MAX_NUM_CLIENTS ) {
			// 이름을 다 받지 못한 경우 --> 나머지를 봇으로 설정
			for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {
				if( db.playerNames[ pn ] == null ) {

					db.isPlayerBots[ pn ] = true;
					db.playerNames [ pn ] = Database.BOT_NAMES[ pn ];
					db.playerStates[ pn ] = Database.WAIT_START;

					frame.setPlayerName( pn, Database.BOT_HEADER + Database.BOT_NAMES[ pn ] );
					frame.focusPlayer( pn );

					frame.logNewLine( "player " + ( pn + 1 ) + " has set to bot" );
				}
			}
		}

		db.numNames   = Database.MAX_NUM_CLIENTS;
		db.numClients = Database.MAX_NUM_CLIENTS;


		// 준비
		frame.setMessage( "게임을 시작하겠습니다." );
		frame.showMessage();

		for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {
			frame.focusPlayer( pn );
		}

		try { Thread.sleep( 1000 ); }
		catch( Exception ex ) {}


		// 라운드 세팅
		String txt = "라운드를 설정하는 중 ";
		frame.setMessage( txt );
		frame.showMessage();

		for( int round = 0; round <= Database.LAST_ROUND; round ++ ) {

			frame.setRound( 0, round );

			txt += "...";
			frame.setMessage( txt );
			frame.showMessage();

			try { Thread.sleep( 100 ); }
			catch( Exception ex ) {}
		}

		try { Thread.sleep( 500 ); }
		catch( Exception ex ) {}


		// 주요 변수 초기화
		db.numOwnDices = new int[ Database.MAX_NUM_CLIENTS ];
		db.numNeuDices = new int[ Database.MAX_NUM_CLIENTS ];
		db.rollResults = new int[ Database.MAX_NUM_DICES   ];

		db.earnMoneys = new int[ Database.LAST_ROUND ][ Database.MAX_NUM_PLAYERS ];

		db.gameStarted = true;

		db.curRound = 0;

		frame.logNewLine( "game statrted" );
	}


	// 라운드 시작하기
	static void startRound() {

		Database db = Application.db;
		VegasFrame frame = db.frame;

		db.curRound ++;

		frame.setRound( db.curRound, Database.LAST_ROUND );

		db.moneyStates      = new int[ Database.NUM_CASINOS ][ Database.MAX_NUM_MONEYS  ];
		db.battingStates    = new int[ Database.NUM_CASINOS ][ Database.MAX_NUM_PLAYERS ];
		db.casinoEarnMoneys = new int[ Database.NUM_CASINOS ][ Database.MAX_NUM_PLAYERS ];

		// 준비
		frame.setMessage( db.curRound + " 라운드를 시작합니다." );
		frame.showMessage();

		frame.removeAllMoneys();
		frame.removeAllBattings();

		for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {
			frame.focusPlayer( pn );

			// 플레이어 상태
			db.playerStates[ pn ] = Database.WAIT_TURN;
		}

		try { Thread.sleep( 1000 ); }
		catch( Exception ex ) {}


		// 카지노 별 돈 세팅
		String txt1 = "카지노에 돈을 거는 중 ";
		frame.setMessage( txt1 );
		frame.showMessage();

		int lenAvMoneys = Database.AVAILABLE_MONEYS.length;
		for( int cn = Database.CASINO_1; cn <= Database.CASINO_6; cn ++ ) {

			int totalGet = 0;
			for( int m = 0; m < Database.MAX_NUM_MONEYS; m ++ ) {

				int i = ( int )( Math.random() * lenAvMoneys );
				int get = Database.AVAILABLE_MONEYS[ i ];
				db.moneyStates[ cn ][ m ] = get;
				frame.addMoney( cn, i );

				txt1 += "...";
				frame.setMessage( txt1 );
				frame.showMessage();

				try { Thread.sleep( 100 ); }
				catch( Exception ex ) {}

				totalGet += get;
				if( totalGet >= Database.MIN_TOTAL_MONEY ) {
					break;
				}
			}
		}


		// 주사위 세팅
		String txt2 = "주사위를 나눠주는 중 ";
		frame.setMessage( txt2 );
		frame.showMessage();

		for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {

			db.numOwnDices[ pn ] = 8;
			if( Database.USE_NEUTRALITY ) {
				db.numNeuDices[ pn ] = 2;
			}
			else {
				db.numNeuDices[ pn ] = 0;
			}

			frame.setPlayerDices( pn, db.numOwnDices[ pn ], db.numNeuDices[ pn ] );

			txt2 += "...";
			frame.setMessage( txt2 );
			frame.showMessage();

			try { Thread.sleep( 100 ); }
			catch( Exception ex ) {}
		}


		frame.removeAllPlayerHighlights();

		frame.logNewLine( "round " + db.curRound + " started" );

		// 가상의 턴 ( nextTurn 에 의해 PLAYER_1 으로 지정됨 )
		db.curTurn = Database.PLAYER_4;
	}


	// 주사위를 모두 소모했는지 확인
	static boolean isThereAnyDices() {

		Database db = Application.db;

		for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {

			if( db.numOwnDices[ pn ] > 0 ) {
				return true;
			}
			if( db.numNeuDices[ pn ] > 0 ) {
				return true;
			}
		}

		db.frame.logNewLine( "all dices are bat" );

		return false;
	}


	// 턴 넘기기
	static void nextTurn() {

		Database db = Application.db;
		VegasFrame frame = db.frame;

		db.playerStates[ db.curTurn ] = Database.WAIT_TURN;

		// 다음 순서 결정
		while( true ) {

			switch( db.curTurn ) {

			case Database.PLAYER_1 :
				db.curTurn = Database.PLAYER_2;
				break;
			case Database.PLAYER_2 :
				db.curTurn = Database.PLAYER_3;
				break;
			case Database.PLAYER_3 :
				db.curTurn = Database.PLAYER_4;
				break;
			case Database.PLAYER_4 :
				db.curTurn = Database.PLAYER_1;
				break;
			default :
				db.curTurn = Database.PLAYER_1;
			}

			int totalNumDices = db.numOwnDices[ db.curTurn ];
			if( Database.USE_NEUTRALITY ) {
				totalNumDices += db.numNeuDices[ db.curTurn ];
			}

			if( totalNumDices == 0 ) {
				// 주사위를 다 배팅했을 경우
				continue;
			}
			else { break; }
		}

		db.playerStates[ db.curTurn ] = Database.WAIT_ROLL;

		frame.blinkPlayer( db.curTurn );
		frame.setMessage( "\"" + db.playerNames[ db.curTurn ] + "\" 님이 던질 차례입니다." );
		frame.showMessage();

		frame.logNewLine( "turn: player " + ( db.curTurn + 1 ) );
	}


	// 롤 메시지 처리
	static void roll() {

		Database db = Application.db;
		VegasFrame frame = db.frame;

		frame.logNewLine( "rolling..." );

		frame.removeAllRollResults();
		frame.showRollResult();

		int k = 0;
		for( int i = 0; i < Database.MAX_NUM_DICES; i ++ ) {
			db.rollResults[ i ] = 0;
		}

		try { Thread.sleep( ( 5 - db.speed ) * 200 ); }
		catch( Exception ex ) {}

		int ownFrom;
		int ownTo;
		int neuFrom;
		int neuTo;

		String resStrOwn = "";
		String resStrNeu = "";

		int numOwnDices = db.numOwnDices[ db.curTurn ];
		ownFrom = 0;
		ownTo = numOwnDices;
		neuFrom = numOwnDices;
		neuTo = numOwnDices;
		for( int i = 0; i < numOwnDices; i ++ ) {
			int res = ( int )( Math.random() * 6.0 ) + 1; // 1 ~ 6
			db.rollResults[ k ++ ] = res;
			frame.addRollResult( db.curTurn, res );
			resStrOwn += ", " + res;

			try { Thread.sleep( ( 5 - db.speed ) * 50 + 50 ); }
			catch( Exception ex ) {}
		}
		resStrOwn = "own: " + ( resStrOwn.length() >= 3 ? resStrOwn.substring( 2 ) : "x" );

		if( Database.USE_NEUTRALITY ) {

			int numNeuDices = db.numNeuDices[ db.curTurn ];
			neuTo += numNeuDices;
			for( int i = 0; i < numNeuDices; i ++ ) {
				int res = ( int )( Math.random() * 6.0 ) + 1; // 1 ~ 6
				db.rollResults[ k ++ ] = res;
				frame.addRollResult( Database.PLAYER_5, res );
				resStrNeu += ", " + res;

				try { Thread.sleep( ( 5 - db.speed ) * 50 + 50 ); }
				catch( Exception ex ) {}
			}
			resStrNeu = " && neu: " + ( resStrNeu.length() >= 3 ? resStrNeu.substring( 2 ) : "x" );
		}

		// 정렬
		frame.removeAllRollResults();
		for( int num = 1; num <= 6; num ++ ) {
			for( int i = 0; i < Database.MAX_NUM_DICES; i ++ ) {
				if( num == db.rollResults[ i ] ) {
					if( ownFrom <= i && i < ownTo ) {
						frame.addRollResult( db.curTurn, num );
					}
					else if( neuFrom <= i && i < neuTo ) {
						frame.addRollResult( Database.PLAYER_5, num );
					}
				}
			}
		}

		frame.logNewLine( "roll results: " + resStrOwn + resStrNeu );

		// 배팅 스테이트
		db.playerStates[ db.curTurn ] = Database.WAIT_BAT;
	}


	// 배팅 메시지 처리
	static void bat() {

		Database db = Application.db;
		VegasFrame frame = db.frame;

		int count = 0;

		int countOwn = 0;
		int countNeu = 0;

		if( !Database.USE_NEUTRALITY ) {

			for( int i = 0; i < Database.MAX_NUM_DICES; i ++ ) {
				if( db.bat == db.rollResults[ i ] ) {
					count ++;
				}
			}

			db.battingStates[ db.bat - 1 ][ db.curTurn ] += count;
			frame.addBatting( db.bat - 1, db.curTurn, count, true );
			frame.setPlayerDices( db.curTurn, db.numOwnDices[ db.curTurn ] -= count, 0 );
		}

		else {

			int i = 0;
			int k = 0;

			for( ; i < db.numOwnDices[ db.curTurn ]; i ++ ) {
				if( db.bat == db.rollResults[ i ] ) {
					countOwn ++;
				}
			}

			for( ; k < db.numNeuDices[ db.curTurn ]; k ++, i ++ ) {
				if( db.bat == db.rollResults[ i ] ) {
					countNeu ++;
				}
			}

			db.battingStates[ db.bat - 1 ][ db.curTurn        ] += countOwn;
			db.battingStates[ db.bat - 1 ][ Database.PLAYER_5 ] += countNeu;
			frame.addBatting( db.bat - 1, db.curTurn,        countOwn, true );
			frame.addBatting( db.bat - 1, Database.PLAYER_5, countNeu, true );
			frame.setPlayerDices( db.curTurn,
					db.numOwnDices[ db.curTurn ] -= countOwn,
					db.numNeuDices[ db.curTurn ] -= countNeu );
		}

		String msg = "\"" + db.playerNames[ db.curTurn ] + "\" 님이 ";
		msg += db.bat + " 번 카지노에 주사위 ";
		if( !Database.USE_NEUTRALITY ) {
			msg += count;
		}
		else {
			msg += ( countOwn + countNeu ) + " ( 자신: " + countOwn + ", 중립: " + countNeu + " )";
		}
		msg += " 개를 걸었습니다.";
		frame.setMessage( msg );
		frame.showMessage();

		frame.logNewLine( "bat: " + db.bat );

		try { Thread.sleep( ( 5 - db.speed ) * 750 ); }
		catch( Exception ex ) {}

		frame.removePlayerHighlight( db.curTurn );
		db.playerStates[ db.curTurn ] = Database.WAIT_TURN;
	}


	// 라운드 종료
	static void endRound() {

		Database db = Application.db;
		VegasFrame frame = db.frame;

		frame.logNewLine( "round " + db.curRound + " end" );

		frame.setMessage( db.curRound + " 라운드 결과를 계산 중입니다." );
		frame.showMessage();
		frame.removeAllBattingBlinks();
		frame.removeAllPlayerHighlights();

		try { Thread.sleep( 1000 ); }
		catch( Exception ex ) {}

		for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {
			frame.focusPlayer( pn );
		}

		// 중복 배팅 제거 - 1 단계
		int[][] reBattingStates = new int[ Database.NUM_CASINOS ][ Database.MAX_NUM_PLAYERS ];
		for( int cn = Database.CASINO_1; cn <= Database.CASINO_6; cn ++ ) {
			for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_5; pn ++ ) {
				reBattingStates[ cn ][ pn ] = db.battingStates[ cn ][ pn ];
			}
		}

		// 중복 배팅 제거 - 2 단계
		for( int cn = Database.CASINO_1; cn <= Database.CASINO_6; cn ++ ) {
			for( int pn1 = Database.PLAYER_1; pn1 <= Database.PLAYER_5; pn1 ++ ) {
				for( int pn2 = pn1 + 1; pn2 <= Database.PLAYER_5; pn2 ++ ) {
					if( db.battingStates[ cn ][ pn1 ] == db.battingStates[ cn ][ pn2 ] ) {
						reBattingStates[ cn ][ pn1 ] = 0;
						reBattingStates[ cn ][ pn2 ] = 0;
					}
				}
			}
		}

		// 중복 배팅 제거 - 3 단계
//		frame.removeAllBattings();
//		for( int cn = Database.CASINO_1; cn <= Database.CASINO_6; cn ++ ) {
//			for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_5; pn ++ ) {
//				if( reBattingStates[ cn ][ pn ] > 0 ) {
//					frame.addBatting( cn, pn, reBattingStates[ cn ][ pn ], false );
//				}
//			}
//		}

		// 번 돈 계산
		// NOTICE : Neu 처리 미완료
		for( int cn = Database.CASINO_1; cn <= Database.CASINO_6; cn ++ ) {
			while( true ) {

				int maxMoney = 0;
				int maxMoneyIdx = -1;

				for( int mn = 0; mn < Database.MAX_NUM_MONEYS; mn ++ ) {
					if( maxMoney < db.moneyStates[ cn ][ mn ] ) {
						maxMoney = db.moneyStates[ cn ][ mn ];
						maxMoneyIdx = mn;
					}
				}

				if( maxMoneyIdx == -1 ) { break; }

				int maxBat = 0;
				int maxBatIdx = -1;

				for( int bn = 0; bn < Database.MAX_NUM_PLAYERS; bn ++ ) {
					if( maxBat < reBattingStates[ cn ][ bn ] ) {
						maxBat = reBattingStates[ cn ][ bn ];
						maxBatIdx = bn;
					}
				}

				if( maxBatIdx == -1 ) { break; }

				db.earnMoneys[ db.curRound - 1 ][ maxBatIdx ] += maxMoney;
				db.moneyStates[ cn ][ maxMoneyIdx ] = 0;
				reBattingStates[ cn ][ maxBatIdx ] = 0;
				db.casinoEarnMoneys[ cn ][ maxBatIdx ] = maxMoney;
			}
		}

		String msg = "이번 라운드에서 번 금액은...";

		frame.setMessage( msg );
		frame.showMessage();

		try { Thread.sleep( 2000 ); }
		catch( Exception ex ) {}

		msg = "각각  ";

		for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) { 
			int earn = 0;
			for( int round = 0; round < Database.LAST_ROUND; round ++ ) {
				earn += db.earnMoneys[ round ][ pn ];
			}
			String earnStr = "";
			if( db.earnMoneys[ db.curRound - 1 ][ pn ] == 0 ) { earnStr += "$0"; }
			else { earnStr += "$" + ( db.earnMoneys[ db.curRound - 1 ][ pn ] / 1000 ) + ",000"; }
			msg += earnStr + "  ";
			frame.setPlayerMoney( pn, earn );
		}

		msg += "입니다.";

		frame.setMessage( msg );
		frame.showMessage();

		try { Thread.sleep( 2000 ); }
		catch( Exception ex ) {}
	}


	// 게임 종료
	static void endGame() {

		Database db = Application.db;
		VegasFrame frame = db.frame;

		frame.logNewLine( "game end" );

		frame.removeAllPlayerHighlights();
		frame.setMessage( "게임이 끝났습니다. 승자는..." );
		frame.showMessage();

		try { Thread.sleep( 2000 ); }
		catch( Exception ex ) {}

		int[] totalEarns = new int[ Database.MAX_NUM_CLIENTS ];
		for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {
			for( int round = 0; round < Database.LAST_ROUND; round ++ ) {
				totalEarns[ pn ] += db.earnMoneys[ round ][ pn ];
			}
		}

		int maxEarn = 0;
		for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {
			if( maxEarn < totalEarns[ pn ] ) {
				maxEarn = totalEarns[ pn ];
			}
		}

		String msg = "";
		for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {
			if( maxEarn == totalEarns[ pn ] ) {
				msg += ", " + db.playerNames[ pn ];
			}
		}
		msg = msg.substring( 2 ) + " 입니다! ( 금액을 확인해보세요. )";

		frame.setMessage( msg );
		frame.showMessage();
	}
}
