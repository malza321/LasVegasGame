
package vegas.ev;

import java.io.*;
import java.net.*;
import vegas.*;
import vegas.gui.*;

public class EventProcessor {



	public static volatile boolean closeServer = false;

	public static volatile boolean disableButtons = false;

	private static volatile boolean processingMessage = false;

	// 동기화됨 ( 모든 이벤트는 이 함수를 통해 처리됨 )
	public static synchronized void process( EventType evType, Object bundle ) {

		disableButtons = true;

		switch( evType ) {

		case OPEN_SERVER :
			processOpenServer();
			break;
		case CLOSE_SERVER :
			processCloseServer();
			break;
		case ACCEPT_CLIENT :
			processAcceptClient( bundle );
			break;
		case BAN_CLIENT :
			processBanClient( bundle );
			break;

		case RECEIVE_MESSAGE :
			processingMessage = true;
			processReceiveMessage( bundle );
			processingMessage = false;
			break;
		}

		disableButtons = false;
	}



	/******************************************************************************************/
	/******************************************************************************************/



	static void processOpenServer() {

		Database db = Application.db;
		VegasFrame frame = db.frame;

		if( db.serverOpened ) { return; }

		try {
			String ipAdrsStr  = frame.getFieldOfIP();
			String portNumStr = frame.getFieldOfPort();

			db.ipAdrs     = InetAddress.getByName( ipAdrsStr );
			db.portNum    = Integer.parseInt( portNumStr );
			db.numClients = 0;
			db.numNames   = 0;

			db.listener = new ServerSocket( db.portNum, 100, db.ipAdrs );
			db.accepter = new ClientAccepter();
			db.accepter.start(); // 어셉터 시작 지점

			for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {

				db.threads[ pn ] = null; 
				db.sockets[ pn ] = null;
				db.readers[ pn ] = null;
				db.writers[ pn ] = null;

				db.isPlayerBots[ pn ] = false;
				db.playerNames [ pn ] = null;
				db.playerDiffs [ pn ] = -1;
				db.playerStates[ pn ] = -1;
				db.lineBufs    [ pn ] = null;

				frame.setPlayerName( pn, Database.EMPTY_NAME );
			}

			db.serverOpened = true;

			frame.logNewLine( "success to open server: " + db.ipAdrs + ":" + db.portNum );
			frame.setOpenedState( true );
			frame.setMessage( "서버의 주소는 ( " + ipAdrsStr + ":" + portNumStr + " ) 입니다." );
			frame.showMessage();
		}

		catch( Exception ex ) {
			frame.logNewLine( "failed to open server" );
			frame.logNewLine( "exception msg: " + ex.getMessage() );
			processCloseServer(); // 다른 처리
		}
	}



	/******************************************************************************************/
	/******************************************************************************************/



	static void processCloseServer() {

		Database db = Application.db;
		VegasFrame frame = db.frame;

		if( !db.serverOpened ) { return; }

		if( db.listener != null ) {
			try { db.listener.close(); }
			catch( Exception ex ) {}
		}
		if( db.accepter != null ) {
			try { db.accepter.interrupt(); }
			catch( Exception ex ) {}
		}

		for( int pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {

			if( db.threads[ pn ] != null ) {
				try { db.threads[ pn ].interrupt(); }
				catch( Exception ex ) {}
			}
			if( db.sockets[ pn ] != null ) {
				try { db.sockets[ pn ].close(); }
				catch( Exception ex ) {}
			}
			if( db.readers[ pn ] != null ) {
				try { db.readers[ pn ].close(); }
				catch( Exception ex ) {}
			}
			if( db.writers[ pn ] != null ) {
				try { db.writers[ pn ].close(); }
				catch( Exception ex ) {}
			}
		}

		db.serverOpened = false;
		db.gameStarted  = false;

		frame.logNewLine( "success to close server" );
		frame.setOpenedState( false );
		frame.setMessage( "서버가 닫혀있습니다." );
		frame.showMessage();

		frame.removeAllMoneys();
		frame.removeAllBattings();
		frame.removeAllBattingBlinks();
		frame.removeAllRollResults();
		frame.removeAllPlayerDices();
		frame.removeAllPlayerNames();
		frame.removeAllPlayerMoneys();
		frame.removeAllPlayerHighlights();
		frame.setRound( 0, 0 );

		try {
			InetAddress adrs = InetAddress.getLocalHost();
			frame.setAddressFields( adrs.getHostAddress(), "33333" );
		}
		catch( Exception ex ) {
			frame.setAddressFields( "127.0.0.1", "33333" );
		}

		closeServer = false;
	}



	/******************************************************************************************/
	/******************************************************************************************/



	static void processAcceptClient( Object bundle ) {

		if( bundle == null ) { return; }

		Database db = Application.db;
		VegasFrame frame = db.frame;

		Socket socket = ( Socket )bundle;
		int pn = -1;

		try {
			if( db.numClients == Database.MAX_NUM_CLIENTS ) {
				// 인원이 다 찬 경우
				throw new Exception();
			}

			// 해당 클라이언트의 번호 결정 및 쓰레드 생성
			for( pn = Database.PLAYER_1; pn <= Database.PLAYER_4; pn ++ ) {
				if( db.threads[ pn ] == null ) {

					db.threads[ pn ] = new ClientThread( pn );
					db.sockets[ pn ] = socket;
					db.readers[ pn ] = new BufferedReader( new InputStreamReader ( socket.getInputStream(),  "utf-8" ) );
					db.writers[ pn ] = new BufferedWriter( new OutputStreamWriter( socket.getOutputStream(), "utf-8" ) );

					frame.blinkPlayer( pn );
					frame.setPlayerName( pn, Database.DEFAULT_NAME );

					db.threads[ pn ].start();

					db.isPlayerBots[ pn ] = false;
					db.playerStates[ pn ] = Database.WAIT_NAME;

					frame.logNewLine( "new client " + ( pn + 1 ) + " connected " + socket.getInetAddress() + ":" + socket.getPort() );

					db.numClients ++;
					return;
				}
			}
		}

		catch( Exception ex1 ) {
			if( pn == -1 ) {
				try { socket.close(); }
				catch( Exception ex2 ) {}
				frame.logNewLine( "a client connected, but no player slot in server ( closed )" );
			}
			else {
				processBanClient( pn ); // 다른 처리
			}
		}
	}



	/******************************************************************************************/
	/******************************************************************************************/



	static void processBanClient( Object bundle ) {

		if( bundle == null ) { return; }

		Database db = Application.db;
		VegasFrame frame = db.frame;

		int pn = ( Integer )bundle;
		if( db.sockets[ pn ] == null ) { return; }


		frame.removePlayerHighlight( pn );

		if( db.serverOpened ) {
			if( db.gameStarted ) {
				db.isPlayerBots[ pn ] = true;
				frame.logNewLine( "client " + ( pn + 1 ) + " disconnected" );
				frame.logNewLine( "client " + ( pn + 1 ) + " has changed to bot" );
				frame.setPlayerName( pn, Database.BOT_HEADER + db.playerNames[ pn ] );

				if( !processingMessage ) {
					// = 클라이언트 메시지를 처리하는 도중이 아니었다면
					// = processReceiveMessage 에서 호출한 것이 아니면
					if( db.curTurn == pn ) {
						if( db.playerStates[ pn ] == Database.WAIT_ROLL ) {
							// 나간 클라이언트가 던지는 순서였을 경우
							db.lineBufs[ pn ] = "roll";
							processingMessage = true;
							processReceiveMessage( pn );
							processingMessage = false;
						}
						else if( db.playerStates[ pn ] == Database.WAIT_BAT ) {
							// 나간 클라이언트가 배팅할 순서였을 경우
							db.lineBufs[ pn ] = "" + GameManager.getBotBatting();
							processingMessage = true;
							processReceiveMessage( pn );
							processingMessage = false;
						}
					}
				}
			}
			else {
				frame.setPlayerName( pn, Database.EMPTY_NAME );
				if( db.playerNames[ pn ] != null ) {
					db.numNames --;
				}
				db.playerNames[ pn ] = null;
				db.numClients --;
				frame.logNewLine( "client " + ( pn + 1 ) + " disconnected" );
			}
		}
		else {
			frame.removePlayerName( pn );
			db.playerNames[ pn ] = null;
			db.numClients --;
		}


		if( db.threads[ pn ] != null ) {
			try { db.threads[ pn ].interrupt(); }
			catch( Exception ex ) {}
			db.threads[ pn ] = null;
		}
		if( db.sockets[ pn ] != null ) {
			try { db.sockets[ pn ].close(); }
			catch( Exception ex ) {}
			db.sockets[ pn ] = null;
		}
		if( db.readers[ pn ] != null ) {
			try { db.readers[ pn ].close(); }
			catch( Exception ex ) {}
			db.readers[ pn ] = null;
		}
		if( db.writers[ pn ] != null ) {
			try { db.writers[ pn ].close(); }
			catch( Exception ex ) {}
			db.writers[ pn ] = null;
		}
	}



	/******************************************************************************************/
	/******************************************************************************************/



	private static boolean checkCloseServer() {

		if( closeServer ) {
			processCloseServer();
			closeServer = false;
			return true;
		}
		else { return false; }
	}

	static void processReceiveMessage( Object bundle ) {

		if( bundle == null ) { return; }

		Database db = Application.db;
		VegasFrame frame = db.frame;

		String msg;
		int pn = ( Integer )bundle;

		while( true ) { // 봇일 경우 continue 를 위한 while 문
			switch( db.playerStates[ pn ] ) {



			case Database.WAIT_NAME : /*============================================================*/
				// 해당 클라이언트의 이름을 받지 못한 상태

				Object[] values;
				try { values = MessageParser.parseNameRankMessage( db.lineBufs[ pn ] ); }
				catch( Exception ex1 ) {
					// 오류 메시지
					msg = MessageCreator.createErrorMessage( ex1.getMessage() );
					try { Transmitter.unicast( pn, msg ); }
					catch( Exception ex2 ) {
						processBanClient( pn ); // 다른 처리
					}
					return;
				}

				// 정상적인 메시지
				db.playerNames [ pn ] = ( String  )values[ 0 ];
				db.playerDiffs [ pn ] = ( Integer )values[ 1 ];
				db.playerStates[ pn ] = Database.WAIT_START;
				frame.setPlayerName( pn, db.playerNames[ pn ] );
				frame.focusPlayer( pn );
				db.numNames ++;

				if( db.numNames == Database.MAX_NUM_CLIENTS ) {
					// 모든 클라이언트의 이름을 받았을 경우 --> 게임 시작

					GameManager.startGame();
					if( checkCloseServer() ) { return; }

					GameManager.startRound();
					if( checkCloseServer() ) { return; }

					msg = MessageCreator.createRoundStartMessage();
					for( int n = Database.PLAYER_1; n <= Database.PLAYER_4; n ++ ) {
						try { Transmitter.unicast( n, msg ); }
						catch( Exception ex ) {
							processBanClient( n ); // 다른 처리
						}
					}
					if( checkCloseServer() ) { return; }

					GameManager.nextTurn();
					if( checkCloseServer() ) { return; }

					msg = MessageCreator.createTurnMessage();
					for( int n = Database.PLAYER_1; n <= Database.PLAYER_4; n ++ ) {
						try { Transmitter.unicast( n, msg ); }
						catch( Exception ex ) {
							processBanClient( n ); // 다른 처리
						}
					}
					if( checkCloseServer() ) { return; }

					if( db.isPlayerBots[ db.curTurn ] ) {
						// 현재 순서가 봇일 경우
						db.lineBufs[ db.curTurn ] = "roll";
						pn = db.curTurn;
						continue;
					}
				}

				break;



			case Database.WAIT_START : /*============================================================*/
				// 해당 클라이언트의 이름을 받았으나 게임 시작을 기다리는 상태

				try { MessageParser.parseStartGameMessage( db.lineBufs[ pn ] ); }
				catch( Exception ex1 ) {
					// 오류 메시지
					msg = MessageCreator.createErrorMessage( ex1.getMessage() );
					try { Transmitter.unicast( pn, msg ); }
					catch( Exception ex2 ) {
						processBanClient( pn ); // 다른 처리
					}
					return;
				}

				// 정상적인 메시지
				GameManager.startGame();
				if( checkCloseServer() ) { return; }

				GameManager.startRound();
				if( checkCloseServer() ) { return; }

				msg = MessageCreator.createRoundStartMessage();
				for( int n = Database.PLAYER_1; n <= Database.PLAYER_4; n ++ ) {
					try { Transmitter.unicast( n, msg ); }
					catch( Exception ex ) {
						processBanClient( n ); // 다른 처리
					}
				}
				if( checkCloseServer() ) { return; }

				GameManager.nextTurn();
				if( checkCloseServer() ) { return; }

				msg = MessageCreator.createTurnMessage();
				for( int n = Database.PLAYER_1; n <= Database.PLAYER_4; n ++ ) {
					try { Transmitter.unicast( n, msg ); }
					catch( Exception ex ) {
						processBanClient( n ); // 다른 처리
					}
				}
				if( checkCloseServer() ) { return; }

				if( db.isPlayerBots[ db.curTurn ] ) {
					// 현재 순서가 봇일 경우
					db.lineBufs[ db.curTurn ] = "roll";
					pn = db.curTurn;
					continue;
				}

				break;



			case Database.WAIT_TURN : /*============================================================*/
				// 해당 클라이언트의 차례가 아닌 상태

				msg = MessageCreator.createErrorMessage( "차례를 기다려주세요." );
				try { Transmitter.unicast( pn, msg ); }
				catch( Exception ex ) {
					processBanClient( pn ); // 다른 처리
				}
				if( checkCloseServer() ) { return; }

				break;



			case Database.WAIT_ROLL : /*============================================================*/
				// 해당 클라이언트가 주사위를 던져야하는 상태

				try { MessageParser.parseRollMessage( db.lineBufs[ pn ] ); }
				catch( Exception ex1 ) {
					// 오류 메시지
					msg = MessageCreator.createErrorMessage( ex1.getMessage() );
					try { Transmitter.unicast( pn, msg ); }
					catch( Exception ex2 ) {
						processBanClient( pn ); // 다른 처리
					}
					if( !db.isPlayerBots[ db.curTurn ] ) {
						// 현재 순서가 봇이 아닐 경우
						return;
					}
				}
				if( checkCloseServer() ) { return; }

				// 정상적인 메시지 ( 봇일 경우 포함 )
				msg = MessageCreator.createRollMessage();
				for( int n = Database.PLAYER_1; n <= Database.PLAYER_4; n ++ ) {
					try { Transmitter.unicast( n, msg ); }
					catch( Exception ex ) {
						processBanClient( n ); // 다른 처리
					}
				}
				if( checkCloseServer() ) { return; }

				GameManager.roll();
				if( checkCloseServer() ) { return; }

				msg = MessageCreator.createRollResultMessage();
				for( int n = Database.PLAYER_1; n <= Database.PLAYER_4; n ++ ) {
					try { Transmitter.unicast( n, msg ); }
					catch( Exception ex ) {
						processBanClient( n ); // 다른 처리
					}
				}
				if( checkCloseServer() ) { return; }

				if( db.isPlayerBots[ db.curTurn ] ) {
					// 현재 순서가 봇일 경우
					db.lineBufs[ db.curTurn ] = "" + GameManager.getBotBatting();
					pn = db.curTurn;
					continue;
				}

				break;



			case Database.WAIT_BAT : /*============================================================*/
				// 해당 클라이언트가 배팅을 해야하는 상태

				try { MessageParser.parseBatMessage( db.lineBufs[ pn ] ); }
				catch( Exception ex1 ) {
					// 오류 메시지
					msg = MessageCreator.createErrorMessage( ex1.getMessage() );
					try { Transmitter.unicast( pn, msg ); }
					catch( Exception ex2 ) {
						processBanClient( pn ); // 다른 처리
					}
					if( db.isPlayerBots[ db.curTurn ] ) {
						// 현재 순서가 봇일 경우
						db.lineBufs[ db.curTurn ] = "" + GameManager.getBotBatting();
					}
					else {
						// 현재 순서가 봇이 아닐 경우
						return;
					}
				}
				if( checkCloseServer() ) { return; }

				// 정상적인 메시지 ( 봇일 경우 포함 )
				msg = MessageCreator.createBatMessage();
				for( int n = Database.PLAYER_1; n <= Database.PLAYER_4; n ++ ) {
					try { Transmitter.unicast( n, msg ); }
					catch( Exception ex ) {
						processBanClient( n ); // 다른 처리
					}
				}
				if( checkCloseServer() ) { return; }

				GameManager.bat();
				if( checkCloseServer() ) { return; }

				if( GameManager.isThereAnyDices() ) {
					// 아직 주사위가 남음
					GameManager.nextTurn();
					if( checkCloseServer() ) { return; }

					msg = MessageCreator.createTurnMessage();
					for( int n = Database.PLAYER_1; n <= Database.PLAYER_4; n ++ ) {
						try { Transmitter.unicast( n, msg ); }
						catch( Exception ex ) {
							processBanClient( n ); // 다른 처리
						}
					}
					if( checkCloseServer() ) { return; }

					if( db.isPlayerBots[ db.curTurn ] ) {
						// 현재 순서가 봇일 경우
						db.lineBufs[ db.curTurn ] = "roll";
						pn = db.curTurn;
						continue;
					}
				}

				else {
					// 남은 주사위 없음 = 한 라운드가 끝남
					GameManager.endRound();
					if( checkCloseServer() ) { return; }

					for( int n = Database.PLAYER_1; n <= Database.PLAYER_4; n ++ ) {
						if( db.playerDiffs[ n ] == Database.DIFF_EASY ) {
							msg = MessageCreator.createRoundResultEasyMessage();
						}
						else if( db.playerDiffs[ n ] == Database.DIFF_NORMAL ) {
							msg = MessageCreator.createRoundResultNormalMessage();
						}
						else {
							msg = MessageCreator.createRoundResultHardMessage();
						}
						try { Transmitter.unicast( n, msg ); }
						catch( Exception ex ) {
							processBanClient( n ); // 다른 처리
						}
					}
					if( checkCloseServer() ) { return; }

					if( db.curRound == Database.LAST_ROUND ) {
						// 모든 라운드 끝남
						GameManager.endGame();
						msg = MessageCreator.createGameFinishMessage();
						for( int n = Database.PLAYER_1; n <= Database.PLAYER_4; n ++ ) {
							try { Transmitter.unicast( n, msg ); }
							catch( Exception ex ) {
								processBanClient( n ); // 다른 처리
							}
						}
						return;
					}

					GameManager.startRound();
					if( checkCloseServer() ) { return; }

					msg = MessageCreator.createRoundStartMessage();
					for( int n = Database.PLAYER_1; n <= Database.PLAYER_4; n ++ ) {
						try { Transmitter.unicast( n, msg ); }
						catch( Exception ex ) {
							processBanClient( n ); // 다른 처리
						}
					}
					if( checkCloseServer() ) { return; }

					GameManager.nextTurn();
					if( checkCloseServer() ) { return; }

					msg = MessageCreator.createTurnMessage();
					for( int n = Database.PLAYER_1; n <= Database.PLAYER_4; n ++ ) {
						try { Transmitter.unicast( n, msg ); }
						catch( Exception ex ) {
							processBanClient( n ); // 다른 처리
						}
					}
					if( checkCloseServer() ) { return; }

					if( db.isPlayerBots[ db.curTurn ] ) {
						// 현재 순서가 봇일 경우
						db.lineBufs[ db.curTurn ] = "roll";
						pn = db.curTurn;
						continue;
					}
				}

				break;



			default :
				break;
			}

			break; // while
		}
	}

	/*
	static void processClientMessage( ClientThread thr ) {

		GameData gData = Application.gData;
		VegasFrame frame = Application.frame;
		HashMap<Integer,ClientThread> cThrs = Application.cThrs;

		if( thr.lineBuf.equals( "start_game" ) && !gData.gameStarted ) {
			int noThrCount = 0;
			for( int n = 1; n <= 4; n ++ ) {
				if( cThrs.get( n ) == null ) {
					noThrCount ++;
				}
			}
			for( int i = 0; i < noThrCount; i ++ ) {
				new BotThread( Application.actr.adrs, SocketAccepter.PORT ).start();
			}
			return;
		}

		if( thr.number != gData.turn ) {
			// 해당 클라이언트의 순서가 아니므로 무시
			// NOTICE: 보내기? 말기?
			return;
		}

		// 순서가 맞는 클라이언트
		if( thr.stat == ClientThread.STAT_WAIT_ROLL ) {
			if( thr.lineBuf.equals( "roll" ) ) {

			}
			else {
				// NOTICE: 잘못된 메시지 처리
				return;
			}
		}
		else if( thr.stat == ClientThread.STAT_WAIT_BAT ) {
			int batNum = -1;
			try {
				batNum = Integer.parseInt( thr.lineBuf );
				if( batNum < 1 || 6 < batNum ) {
					throw new NumberFormatException();
				}
				if( gData.rollResCounts[ batNum - 1 ] == 0 ) {
					throw new NumberFormatException();
				}

				// 배팅해주기
				// 카지노 ( batNum ) 에 플레이어 ( thr.number ) 가 count 만큼 배팅
				int count = gData.rollResCounts[ batNum - 1 ];
				gData.battings[ batNum - 1 ][ thr.number - 1 ] += count;
				frame.addBatting( batNum, frame.getPlayerRGB( thr.number ), count );
				frame.showMessage( thr.name + " (이)가 " + batNum + " 번 카지노에 " + count + " 개를 걸었습니다." );
				int remain = gData.curDices[ thr.number - 1 ] -= count;
				frame.setPlayerDiceNumber( thr.number, remain );

				try {
					Thread.sleep( 2500 );
				}
				catch( InterruptedException ex ) {
					ex.printStackTrace();
				}

				Transmitter.broadcast( thr.lineBuf );

				// 모든 플레이어의 주사위가 배팅됐는지 확인
				boolean allBat = true;
				for( int i = 0; i < gData.curDices.length; i ++ ) {
					if( gData.curDices[ i ] > 0 ) {
						allBat = false;
						break;
					}
				}
				if( allBat ) {
					// 모든 플레이어의 모든 주사위가 배팅됨 ( 라운드 끝 )

					int[] moneyCounts = new int[ GameData.NUM_CASINOS ];
					for( int i = 0; i < GameData.NUM_CASINOS; i ++ ) {
						Arrays.sort( gData.moneys[ i ] );
						for( int k = GameData.MAX_NUM_MONEYS - 1; k >= 0; k -- ) {
							if( gData.moneys[ i ][ k ] > 0 ) {
								moneyCounts[ i ] ++;
							}
						}
					}
					for( int i = 0; i < GameData.NUM_CASINOS; i ++ ) {
						for( int k = 0; k < SocketAccepter.MAX_CLIENTS; k ++ ) {
							int val = gData.battings[ i ][ k ];
							for( int x = k + 1; x < SocketAccepter.MAX_CLIENTS; x ++ ) {
								if( val == gData.battings[ i ][ x ] ) {
									gData.battings[ i ][ k ] = 0;
									gData.battings[ i ][ x ] = 0;
								}
							}
						}
					}
					for( int i = 0; i < GameData.NUM_CASINOS; i ++ ) {
						for( int k = 0; k < moneyCounts[ i ]; k ++ ) {
							int maxMoney = gData.moneys[ i ][ GameData.MAX_NUM_MONEYS - 1 - k ];

							int maxBat = 0;
							int xx = -1;
							for( int x = 0; x < SocketAccepter.MAX_CLIENTS; x ++ ) {
								if( gData.battings[ i ][ x ] > maxBat ) {
									maxBat = gData.battings[ i ][ x ];
									xx = x;
								}
							}
							if( xx != -1 ) {
								gData.battings[ i ][ xx ] = 0;
							}
							if( maxBat != 0 ) {
								gData.playerMoneys[ xx ] += maxMoney;
							}
						}
					}

					String txt1 = gData.curRound + " 현재 돈은 각각";
					String txt2 = "";
					for( int i = 0; i < SocketAccepter.MAX_CLIENTS; i ++ ) {
						if( gData.playerMoneys[ i ] != 0 ) {
							int front = ( gData.playerMoneys[ i ] / 1000 );
							txt2 += " $" + front + ",000";
						}
						else {
							txt2 += " $0";
						}
					}
					txt1 += txt2 + " 입니다.";
					frame.showMessage( txt1 );

					String msg = "";
					for( int i = 0; i < gData.playerMoneys.length; i ++ ) {
						msg += "," + gData.playerMoneys[ i ];
					}
					Transmitter.broadcast( msg.substring( 1 ) );

					try {
						Thread.sleep( 5000 );
					}
					catch( InterruptedException ex ) {
						ex.printStackTrace();
					}

					gData.curRound ++;

					if( gData.curRound > GameData.MAX_NUM_ROUNDS ) {
						// 게임 끝 --> 서버 다시 켜야 함
						Integer[] playerNums = { 1, 2, 3, 4 };
						Arrays.sort( playerNums, new Comparator<Integer>() {

							@Override
							public int compare( Integer arg0, Integer arg1 ) {

								return gData.playerMoneys[ arg0 - 1 ] - gData.playerMoneys[ arg1 - 1 ];
							}
						});
						Arrays.sort( gData.playerMoneys );
						String names = "";
						for( int i = gData.playerMoneys.length - 1; i >= 0; i -- ) {
							names += ", " + cThrs.get( playerNums[ i ] ).name;
							if( gData.playerMoneys[ i ] > gData.playerMoneys[ i - 1 ] ) {
								break;
							}
						}
						names = names.substring( 2 ).trim();

						frame.showMessage( "승자는 " + names + " 입니다! 앱을 다시 켜주세요." );

						for( int i = 1; i <= SocketAccepter.MAX_CLIENTS; i ++ ) {
							processClientError( cThrs.get( i ) );
						}

						frame.clearAllPlayerNames();
						frame.clearHighlights();
						return;
					}					

					// 카지노 별 돈 세팅
					frame.removeAllBattings();
					frame.removeAllDices();
					frame.removeAllMoneys();

					gData.moneys = new int[ GameData.NUM_CASINOS ][ GameData.MAX_NUM_MONEYS ];
					gData.battings = new int[ GameData.NUM_CASINOS ][ SocketAccepter.MAX_CLIENTS ];

					Object[] objs = new Object[ 9 ];
					for( int i = 0; i < 9; i ++ ) {
						objs[ i ] = new Integer( 10000 * ( i + 1 ) );
					}
					SelectionMachine sm = new SelectionMachine( objs );
					for( int i = 0; i < GameData.NUM_CASINOS; i ++ ) {
						gData.totalMoneys[ i ] = 0;
						int k = 0;
						while( true ) { 
							int res = ( Integer )sm.getCombination( 1, false )[ 0 ];
							gData.moneys[ i ][ k ++ ] = res;
							gData.totalMoneys[ i ] += res;
							if( gData.totalMoneys[ i ] >= 50000 ) {
								break;
							}
						}
					}

					// GUI 반영
					for( int i = 0; i < GameData.NUM_CASINOS; i ++ ) {
						for( int k = 0; k < GameData.MAX_NUM_MONEYS; k ++ ) {
							frame.addMoney( i + 1, gData.moneys[ i ][ k ] );
						}
					}

					for( int i = 0; i < SocketAccepter.MAX_CLIENTS; i ++ ) {
						gData.curDices[ i ] = 8;
						frame.setPlayerDiceNumber( i + 1, 8 );
					}
					frame.setRound( gData.curRound, GameData.MAX_NUM_ROUNDS );

					// 카운트 애니메이션
					for( int i = 5; i >= 1; i -- ) {
						try {
							frame.showMessage( "라운드를 시작합니다! " + i + "..." );
							Thread.sleep( 1000 );
						}
						catch( Exception ex ) {
							ex.printStackTrace();
						}
					}

					// 게임 데이터 초기화 2
					// 1 번 플레이어로부터만 roll 메시지를 받기를 기다리는 상태
					// 나머지는 turn 을 기다리는 상태
					int num = 1;
					gData.turn = 1;
					cThrs.get( num ++ ).stat = ClientThread.STAT_WAIT_ROLL;
					for( ; num <= SocketAccepter.MAX_CLIENTS; num ++ ) {
						cThrs.get( num ).stat = ClientThread.STAT_WAIT_TURN;
					}
					gData.rollResults.clear();

					// GUI 반영
					frame.showMessage( cThrs.get( gData.turn ).name + " (이)가 던질 차례입니다." );
					frame.clearHighlights();
					frame.highlightPlayer( gData.turn );

					// 브로드캐스트 라운드 시작 메시지
					msg = "round_start&";
					for( int n = 1; n <= SocketAccepter.MAX_CLIENTS; n ++ ) {
						msg += cThrs.get( n ).name;
						if( n < SocketAccepter.MAX_CLIENTS ) {
							msg += ",";
						}
					}
					msg += "&";
					for( int i = 0; i < GameData.NUM_CASINOS; i ++ ) {
						for( int k = 0; k < GameData.MAX_NUM_MONEYS; k ++ ) {
							msg += gData.moneys[ i ][ k ];
							if( k < GameData.MAX_NUM_MONEYS - 1 ) {
								msg += ",";
							}
						}
						if( i < GameData.NUM_CASINOS - 1 ) {
							msg += "#";
						}
					}

					Transmitter.broadcast( msg );

					return;
				}

				// 차례 넘기기 ( 주사위가 있는 사람에게 )
				// 누군가 주사위가 남음
				while( true ) {
					if( gData.turn == 1 ) {
						gData.turn = 2;
						if( gData.curDices[ gData.turn - 1 ] == 0 ) {
							continue;
						}
					}
					else if( gData.turn == 2 ) {
						gData.turn = 3;
						if( gData.curDices[ gData.turn - 1 ] == 0 ) {
							continue;
						}
					}
					else if( gData.turn == 3 ) {
						gData.turn = 4;
						if( gData.curDices[ gData.turn - 1 ] == 0 ) {
							continue;
						}
					}
					else if( gData.turn == 4 ) {
						gData.turn = 1;
						if( gData.curDices[ gData.turn - 1 ] == 0 ) {
							continue;
						}
					}
					break;
				}

				for( int n = 1; n <= 4; n ++ ) {
					ClientThread cThr = cThrs.get( n );
					if( cThr.number == gData.turn ) {
						cThr.stat = ClientThread.STAT_WAIT_ROLL;
					}
					else {
						cThr.stat = ClientThread.STAT_WAIT_TURN;
					}
				}

				frame.clearHighlights();
				frame.highlightPlayer( gData.turn );
				frame.showMessage( cThrs.get( gData.turn ).name + " (이)가 던질 차례입니다." );

				return;
			}
			catch( NumberFormatException ex ) {
				// NOTICE: 잘못된 메시지 처리
				return;
			}
		}
		else {
			// X
			return;
		}



	 */


	/*// 클라이언트 메시지 파싱
		String line = thr.lineBuf;
		String[] parts = line.split( "&" );
		String msgType = parts[ 0 ].toLowerCase();
		String data = null;

		// 메시지 타입 및 데이터 확인
		try {
			if( msgType.equals( "res_name" ) ) {
				if( parts.length != 2 ) {
					// 형식 오류
					thr.writer.write( "err_format&invalid_name\n" );
				}
				else {
					data = parts[ 1 ];
				}
			}
			else if( msgType.equals( "res_roll" ) ) {
				// X
			}
			else if( msgType.equals( "res_bat" ) ) {
				if( parts.length != 2 ) {
					// 형식 오류
					thr.writer.write( "err_format&invalid_bat\n" );
				}
				else {
					data = parts[ 1 ];
				}
			}
			else {
				// 알 수 없는 메시지타입
				thr.writer.write( "err_format&unknown_type" );
				return;
			}
		}
		catch( Exception ex ) {
			processClientError( thr );
		}*/

	/*int stat = thr.stat;
		if( stat == ClientThread.STAT_WAIT_START ) {

		}





		// 클라이언트 상태
		int stat = thr.stat;
		int readCount = ++ thr.readCounts[ stat ];
		int maxReadCount = ClientThread.MAX_READLINE_TRYS[ stat ];

		// 데이터 확인 또는 처리
		if( stat == ClientThread.STAT_WAIT_START ) {

			// 파싱
			String line = thr.lineBuf;
			String[] parts = line.split( "&" );
			String msgType = parts[ 0 ].toLowerCase();

			// 메시지 형식 확인
			if( !msgType.equals( "res_name" ) ) {
				try {
					thr.writer.write( "err_format&invalid_msg_type" );
					if( readCount == maxReadCount ) {
						// readCount 허용치에 다다름
						// NOTICE: 무작위 이름
						// --
					}
					else {
						return;
					}
				}
				catch( Exception ex ) {
					// 스트림 오류
					processClientError( thr );
					return;
				}
			}

			String data = null;

			// 데이터 == 이름
			thr.name = data;

			VegasFrame frame = Application.frame;

			Object[] vals = Application.cThrs.values().toArray();
			for( int i = 0; i < vals.length; i ++ ) {
				ClientThread cThr = ( ClientThread )vals[ i ];
				if( thr.number == cThr.number ) {
					// 자신의 번호는 생략
					continue;
				}
				if( cThr.name.equals( thr.name ) ) {
					// 이름 중복
					frame.logNewLine( "ev proc: duplicate name received > " + thr.name, VegasFrame.LOG_STDERR );
					try {
						thr.writer.write( "err_format&duplicate_name\n" );
					}
					catch( Exception ex ) {
						processClientError( thr );
					}
					return;
				}
			}

			thr.readCounts[ stat ] = 0;
			thr.stat = ClientThread.STAT_WAIT_START;
			frame.setPlayerName( thr.number, thr.name );
			frame.logNewLine( "ev proc: name set > " + thr.name, VegasFrame.LOG_STDOUT );
		}

		else if( stat == ClientThread.STAT_WAIT_START ) {

		}

		else if( stat == ClientThread.STAT_WAIT_TURN ) {

		}

		else if( stat == ClientThread.STAT_WAIT_ROLL ) {

		}

		else if( stat == ClientThread.STAT_WAIT_BAT ) {

		}

		else {
			// X
		}*/
}

/*
	static void processClientTimeout( ClientThread thr ) {

		// 스탯 확인
		int stat = thr.stat;

		if( stat == ClientThread.STAT_WAIT_START ) {
			// X
		}

		else if( stat == ClientThread.STAT_WAIT_TURN ) {
			// X
		}

		else if( stat == ClientThread.STAT_WAIT_ROLL ) {
			// NOTICE: 서버가 자동 roll
		}

		else if( stat == ClientThread.STAT_WAIT_BAT ) {
			// NOTICE: 서버가 자동 bat
		}

		else {
			// X
		}
	}


	static void processClientInterrupted( ClientThread thr ) {

		// 소켓 닫기
		Socket socket = thr.socket;
		try {
			socket.close();
		}
		catch( Exception ex ) {
			// X
		}

		GameData gData = Application.gData;
		VegasFrame frame = Application.frame;
		SocketAccepter actr = Application.actr;
		HashMap<Integer,ClientThread> cThrs = Application.cThrs;

		// 쓰레드 등록 해제
		cThrs.remove( thr.number );

		// 게임 시작 여부
		if( gData.gameStarted ) {
			// 봇으로 대체
			gData.isBots[ thr.number - 1 ] = true;
			frame.setPlayerName( thr.number, GameData.BOT_NAME );
			if( gData.turn == thr.number ) {
				// 나가리된 플레이어가 원래 순서였을 경우
				// NOTICE: 랜덤 알고리즘
			}
		}
		else {
			frame.clearPlayerName( thr.number );
			actr.numClients --;
		}
	}

	static void processClientError( ClientThread thr ) {

		// 소켓 닫기
		Socket socket = thr.socket;
		try {
			socket.close();
		}
		catch( Exception ex ) {
			// X
		}

		GameData gData = Application.gData;
		VegasFrame frame = Application.frame;
		SocketAccepter actr = Application.actr;
		HashMap<Integer,ClientThread> cThrs = Application.cThrs;

		// 쓰레드 등록 해제
		cThrs.remove( thr.number );

		// 게임 시작 여부
		if( gData.gameStarted ) {
			// 봇으로 대체
			gData.isBots[ thr.number - 1 ] = true;
			frame.setPlayerName( thr.number, GameData.BOT_NAME );
			if( gData.turn == thr.number ) {
				// 나가리된 플레이어가 원래 순서였을 경우
				// NOTICE: 랜덤 알고리즘
			}
		}
		else {
			frame.clearPlayerName( thr.number );
			actr.numClients --;
		}
	}
}
 */