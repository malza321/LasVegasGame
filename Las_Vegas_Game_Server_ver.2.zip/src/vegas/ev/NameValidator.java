
package vegas.ev;

import vegas.*;

class NameValidator {

	private static final String[] INVALIDS = {

			"/", "&", ",", "@", "-", "[", "]", "?",
			"server", "bot",
			"easy", "normal", "hard",
			"round_start", "round_result",
			"game_finish", "empty", "none",
			"turn", "roll", "bat"
	};

	static boolean validate( String name ) {

		Database db = Application.db;
		name = name.toLowerCase();

		if( name.length() == 0 ) {
			return false;
		}

		for( int i = 0; i < INVALIDS.length; i ++ ) {
			if( name.contains( INVALIDS[ i ] ) ) {
				return false;
			}
		}

		for( int i = 0; i < Database.MAX_NUM_CLIENTS; i ++ ) {
			if( db.playerNames[ i ] != null ) {
				if( name.equals( db.playerNames[ i ] ) ) {
					return false;
				}
			}
			if( name.equals( Database.BOT_NAMES[ i ] ) ) {
				return false;
			}
		}

		if( name.equals( Database.EMPTY_NAME ) ) {
			return false;
		}

		if( name.equals( Database.DEFAULT_NAME ) ) {
			return false;
		}

		return true;
	}
}
