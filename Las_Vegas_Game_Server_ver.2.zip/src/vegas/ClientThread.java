
package vegas;

import vegas.ev.*;

public class ClientThread extends Thread {

	public final int n;

	public ClientThread( int n ) { this.n = n; }

	@Override
	public void run() {

		Database db = Application.db;

		while( true ) {
			try {
				db.lineBufs[ n ] = db.readers[ n ].readLine();
				sleep( 0 );
				if( db.lineBufs[ n ] == null ) {
					throw new Exception( "buf is null" );
				}
				EventProcessor.process( EventType.RECEIVE_MESSAGE, n );
			}
			catch( Exception ex ) {
				EventProcessor.process( EventType.BAN_CLIENT, n );
				return;
			}
		}
	}
}
