
package vegas.gui;

public interface VegasListener {

	public abstract void action();
}
