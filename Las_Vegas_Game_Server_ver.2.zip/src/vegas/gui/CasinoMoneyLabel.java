
package vegas.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class CasinoMoneyLabel extends JLabel {

	private static final long serialVersionUID = 2028362361663182L;

	private final CasinoMoneyLabel ref;

	int amount;

	CasinoMoneyLabel() {

		ref = this;

		this.setHorizontalAlignment( JLabel.CENTER );
		this.setForeground( Color.BLACK );
		this.setOpaque( true );

		this.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int w = ref.getWidth();
				int h = ref.getHeight();

				ref.setFont( new Font( "맑은 고딕", Font.BOLD, h * 3 / 4 ) );

				int q1 = w / 100;
				int q2 = h / 100;

				ref.setBorder( new MatteBorder( q2, q1, q2, q1, Color.BLACK ) );
			}
		});
	}
}
