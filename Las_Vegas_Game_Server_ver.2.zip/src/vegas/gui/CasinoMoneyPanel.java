
package vegas.gui;

import java.awt.*;
import javax.swing.*;

class CasinoMoneyPanel extends JPanel {

	private static final long serialVersionUID = -8823341059284034947L;

	private static final int NUM_MONEY_SLOTS = VegasFrame.NUM_MONEY_SLOTS;

	final JPanel[] containers;

	CasinoMoneyPanel() {

		containers = new JPanel[ NUM_MONEY_SLOTS ];
		for( int i = 0; i < NUM_MONEY_SLOTS; i ++ ) {

			containers[ i ] = new JPanel();
			containers[ i ].setOpaque( false );
			containers[ i ].setLayout( new BorderLayout() );

			this.add( containers[ i ] );
		}

		this.setOpaque( false );
		this.setLayout( new LayoutManager() {

			@Override
			public void addLayoutComponent( String name, Component comp ) {}

			@Override
			public void removeLayoutComponent( Component comp ) {}

			@Override
			public Dimension preferredLayoutSize( Container parent ) { return null; }

			@Override
			public Dimension minimumLayoutSize( Container parent ) { return null; }

			@Override
			public void layoutContainer( Container parent ) {

				int pw = parent.getWidth();
				int ph = parent.getHeight();

				int mw = pw / 25;
				int mh = ph / 25;

				int x = mw;
				int y = mh;
				int w = ( pw - 2 * mw );
				int h = ( ph - ( NUM_MONEY_SLOTS + 1 ) * mh ) / NUM_MONEY_SLOTS;

				for( int i = 0; i < NUM_MONEY_SLOTS; i ++ ) {
					containers[ i ].setBounds( x, y, w, h );
					y += mh + h;
				}
			}
		});
	}
}
