
package vegas.gui;

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;

class VegasResource {

	static void registerFont( String path ) {

		try {
			URL ttfURL = ClassLoader.getSystemResource( path );
			InputStream in = ttfURL.openStream();
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
			ge.registerFont( Font.createFont( Font.TRUETYPE_FONT, in ) );
		}
		catch( Exception ex ) {
			// NEVER
			ex.printStackTrace();
		}
	}

	static BufferedImage loadImage( String path ) {

		BufferedImage bimg = null;

		URL res = ClassLoader.getSystemResource( path );
		try {
			bimg = ImageIO.read( res );
		}
		catch( IOException ex ) {
			// NEVER
			ex.printStackTrace();
			bimg = null;
		}

		return bimg;
	}
}
