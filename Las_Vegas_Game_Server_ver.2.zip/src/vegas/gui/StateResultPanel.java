
package vegas.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class StateResultPanel extends JPanel {

	private static final long serialVersionUID = 6595706704032673919L;

	final JLabel text;

	final JPanel rolls;

	StateResultPanel() {

		text = new JLabel( "주사위 결과 >" );
		text.setForeground( Color.WHITE );
		text.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int h = text.getHeight();

				text.setFont( new Font( "맑은 고딕", Font.BOLD, h * 3 / 7 ) );
				text.setBorder( new EmptyBorder( 0, h / 3, 0, h / 3 ) );
			}
		});

		rolls = new JPanel();
		rolls.setOpaque( false );
		rolls.setLayout( new LayoutManager() {

			@Override
			public void addLayoutComponent( String name, Component comp ) {}

			@Override
			public void removeLayoutComponent( Component comp ) {}

			@Override
			public Dimension preferredLayoutSize( Container parent ) { return null; }

			@Override
			public Dimension minimumLayoutSize( Container parent ) { return null; }

			@Override
			public void layoutContainer( Container parent ) {

				int ph = parent.getHeight();
				Component[] comps = parent.getComponents();

				int x = ph / 7;
				int y = x;
				int w = ph * 3 / 4;
				int h = w;

				for( int i = 0; i < comps.length; i ++ ) {
					comps[ i ].setBounds( x, y, w, h );
					x += y + w;
				}
			}
		});

		this.setOpaque( true );
		this.setBackground( VegasFrame.PANEL_BACKGROUND );
		this.add( text );
		this.add( rolls );
		this.setLayout( new LayoutManager() {

			@Override
			public void addLayoutComponent( String name, Component comp ) {}

			@Override
			public void removeLayoutComponent( Component comp ) {}

			@Override
			public Dimension preferredLayoutSize( Container parent ) { return null; }

			@Override
			public Dimension minimumLayoutSize( Container parent ) { return null; }

			@Override
			public void layoutContainer( Container parent ) {

				int pw = parent.getWidth();
				int ph = parent.getHeight();

				int w = text.getPreferredSize().width;
				int h = ph;

				text.setBounds( 0, 0, w, h );

				rolls.setBounds( w, 0, pw - w, h );
			}
		});
	}
}
