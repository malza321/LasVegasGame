
package vegas.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class CasinoPanel extends JPanel {

	private static final long serialVersionUID = -8705969372764383381L;

	final JLabel nameLabel;

	final CasinoMoneyPanel moneyPanel;

	final CasinoBattingPanel battingPanel;

	CasinoPanel() {

		nameLabel = new JLabel();
		nameLabel.setForeground( Color.WHITE );
		nameLabel.setHorizontalAlignment( JLabel.CENTER );
		nameLabel.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int h = nameLabel.getHeight();

				nameLabel.setFont( new Font( "맑은 고딕", Font.BOLD, h * 1 / 2 ) );
				nameLabel.setBorder( new MatteBorder( 0, 0, h / 20, 0, Color.WHITE ) );
			}
		});

		moneyPanel = new CasinoMoneyPanel();

		battingPanel = new CasinoBattingPanel();

		this.setBackground( VegasFrame.PANEL_BACKGROUND );
		this.add( nameLabel );
		this.add( moneyPanel );
		this.add( battingPanel );
		this.setLayout( new LayoutManager() {

			@Override
			public void addLayoutComponent( String name, Component comp ) {}

			@Override
			public void removeLayoutComponent( Component comp ) {}

			@Override
			public Dimension preferredLayoutSize( Container parent ) { return null; }

			@Override
			public Dimension minimumLayoutSize( Container parent ) { return null; }

			@Override
			public void layoutContainer( Container parent ) {

				int pw = parent.getWidth();
				int ph = parent.getHeight();

				int x = 0;
				int y = 0;
				int w = pw;
				int h = ph / 7;

				nameLabel.setBounds( x, y, w, h );

				y = h;
				w = pw * 3 / 5;
				h = ph - y;

				moneyPanel.setBounds( x, y, w, h );

				x += w;
				w = pw - w;

				battingPanel.setBounds( x, y, w, h );
			}
		});
	}
}
