
package vegas.gui;

import java.awt.*;
import javax.swing.*;

class DiceShape extends JPanel {

	private static final long serialVersionUID = 6073466555384036792L;

	int number;

	Color background;
	Color foreground;

	DiceShape() {

		this.setOpaque( false );
	}

	@Override
	public void paintComponent( Graphics g ) {

		int tw = this.getWidth();
		int th = this.getHeight();

		// 정사각형으로 가정
		int s;
		if( tw > th ) {
			s = th;
		}
		else {
			s = tw;
		}

		int r = s / 8;
		Graphics2D g2 = ( Graphics2D ) g;
		g2.setRenderingHint(
				RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON );


		/*===========================================*/


		g2.setColor( background );
		g2.fillRoundRect( 0, 0, s, s, s / 2, s / 2 );

		g2.setColor( VegasFrame.DICE_BORDER_COLOR );
		g2.setStroke( new BasicStroke( 2.5f ) );
		g2.drawRoundRect( 0, 0, s, s, s / 2, s / 2);

		g2.setColor( foreground );

		int dia = 2 * r;
		int left, top;

		if( number == 1 ) {
			// 모양 1

			int x = s / 2;
			int y = x;

			left = x - r + 1;
			top = y - r + 1;
			g2.fillOval( left, top, dia, dia );
		}

		else if( number == 2 ) {
			// 2 모양

			int x = s * 2 / 3;
			int y = s / 3;

			left = x - r + 1;
			top = y - r + 1;
			g2.fillOval( left, top, dia, dia );

			int t = x;
			x = y;
			y = t;

			left = x - r + 1;
			top = y - r + 1;
			g2.fillOval( left, top, dia, dia );
		}

		else if( number == 3 ) {
			// 3 모양

			int x = s / 2;
			int y = x;

			left = x - r + 1;
			top = y - r + 1;
			g2.fillOval( left, top, dia, dia );

			x = s * 3 / 4;
			y = s / 4;

			left = x - r + 1;
			top = y - r + 1;
			g2.fillOval( left, top, dia, dia );

			int t = x;
			x = y;
			y = t;

			left = x - r + 1;
			top = y - r + 1;
			g2.fillOval( left, top, dia, dia );
		}

		else if( number == 4 ) {
			// 4 모양

			int p1 = s * 2 / 7;
			int p2 = s * 5 / 7;

			left = p1 - r + 1;
			top = p1 - r + 1;
			g2.fillOval( left, top, dia, dia );

			left = p1 - r + 1;
			top = p2 - r + 1;
			g2.fillOval( left, top, dia, dia );

			left = p2 - r + 1;
			top = p1 - r + 1;
			g2.fillOval( left, top, dia, dia );

			left = p2 - r + 1;
			top = p2 - r + 1;
			g2.fillOval( left, top, dia, dia );
		}

		else if( number == 5 ) {
			// 5 모양

			int p1 = s * 3 / 11;
			int p2 = s * 8 / 11;

			left = p1 - r + 1;
			top = p1 - r + 1;
			g2.fillOval( left, top, dia, dia );

			left = p1 - r + 1;
			top = p2 - r + 1;
			g2.fillOval( left, top, dia, dia );

			left = p2 - r + 1;
			top = p1 - r + 1;
			g2.fillOval( left, top, dia, dia );

			left = p2 - r + 1;
			top = p2 - r + 1;
			g2.fillOval( left, top, dia, dia );

			int x = s / 2;
			int y = x;

			left = x - r + 1;
			top = y - r + 1;
			g2.fillOval( left, top, dia, dia );
		}

		else if( number == 6 ) {
			// 6 모양

			int x1 = s * 4 / 13;
			int x2 = s * 9 / 13;
			int y1 = s * 2 / 9;
			int y2 = s / 2;
			int y3 = s * 7 / 9;

			left = x1 - r + 1;
			top = y1 - r + 1;
			g2.fillOval( left, top, dia, dia );

			left = x1 - r + 1;
			top = y2 - r + 1;
			g2.fillOval( left, top, dia, dia );

			left = x1 - r + 1;
			top = y3 - r + 1;
			g2.fillOval( left, top, dia, dia );

			left = x2 - r + 1;
			top = y1 - r + 1;
			g2.fillOval( left, top, dia, dia );

			left = x2 - r + 1;
			top = y2 - r + 1;
			g2.fillOval( left, top, dia, dia );

			left = x2 - r + 1;
			top = y3 - r + 1;
			g2.fillOval( left, top, dia, dia );
		}

		else {
			// 오류
		}
	}
}
