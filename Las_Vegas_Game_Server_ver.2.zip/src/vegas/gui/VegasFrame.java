
/* 화면 설정 */
/* 화면값 받아오기 */
// setScreen( boolean screen )
// getScreen()

/* 로그 라인 추가 */
/* 로그 모든 라인 제거 */
// logNewLine( String line )
// logClearLines()

/* 한 카지노에 하나의 돈 추가 */
/* 한 카지노에 하나의 배팅 추가 */
/* 모든 카지노의 모든 돈 제거 */
/* 모든 카지노의 모든 배팅 제거 */
/* 모든 배팅 깜빡임 제거 */
// addMoney( int casinoNum, int moneyAmount )
// addBatting( int casinoNum, int playerNum, int count, boolean blink )
// removeAllMoneys()
// removeAllBattings()
// removeAllBattingBlinks()

/* 밴 확인 패널 띄우기 ( 텍스트 ) */
/* 밴 확인 패널 띄우기 ( 플레이어번호 + 텍스트 ) */
// showBanConfirmPanel( String txt )
// showBanConfirmPanel( int playerNum, String txt )

/* 메시지 띄우기 */
/* 메시지 설정 */
// showMessage()
// setMessage( String msg )

/* 주사위 결과 띄우기 */
/* 한 주사위 결과 추가 */
/* 모든 주사위 결과 제거 */
// showRollResult()
// addRollResult( int playerNum, int diceNum )
// removeAllRollResults()

/* 라운드 설정 */
// setRound( int current, int max )

/* 특정 플레이어의 이름 설정 */
/* 특정 플레이어의 이름 제거 */
/* 모든 플레이어의 이름 제거 */
// setPlayerName( int playerNum, String name )
// removePlayerName( int playerNum )
// removeAllPlayerNames()

/* 특정 플레이어의 주사위 수 설정 */
/* 특정 플레이어의 주사위 제거 ( 0 으로 ) */
/* 모든 플레이어의 주사위 제거 ( 0 으로 ) */
// setPlayerDices( int playerNum, int ownCount, int neutralityCount )
// removePlayerDices( int playerNum )
// removeAllPlayerDices()

/* 특정 플레이어의 돈 설정 ( $10,000 단위만 가능 ) */
/* 모든 플레이어의 돈 제거 ( 공백으로 ) */
// setPlayerMoney( int playerNum, int moneyAmount )
// removeAllPlayerMoneys()

/* 특정 플레이어에 포커스 설정 */
/* 특정 플레이어에 깜박임 설정 */
/* 특정 플레이어의 포커스 해제 */
/* 특정 플레이어의 깜박임 해제 */
/* 모든 플레이어의 하이라이트 ( 포커스 + 깜박임 ) 제거 */
// focusPlayer( int playerNum )
// blinkPlayer( int playerNum )
// removePlayerHighlight( int playerNum )
// removeAllPlayerHighlights()

/* 주소 필드값 설정 */
/* IP주소값 받기 */
/* 포트번호값 받기 */
/* 오픈 상태 설정 */
// setAddressFields( String ip, String port )
// getFieldOfIP()
// getFieldOfPort()
// setOpenedState( boolean val )

/* 서버 열기/닫기 리스너 설정 */
/* 로그 클리어 리스너 설정 */
/* 게임 속도 변경 리스너 설정 */
/* 화면전환 리스너 설정 */
/* 플레이어 클릭 리스너 설정 */
/* 플레이어 벤 리스너 설정 */
// setOpenCloseServerListener( VegasListener lis )
// setClearLogListener( VegasListener lis )
// setGameSpeedListener( VegasListener lis )
// setSwitchScreenListener( VegasListener lis )
// setClickPlayerListener( int playerNum, VegasListener lis )
// setBanPlayerListener( int playerNum, VegasListener lis )

package vegas.gui;

import java.util.*;
import java.awt.*;
import javax.swing.*;

public class VegasFrame extends JFrame {


	private static final long serialVersionUID = -1966090415318542313L;

	// 중립주사위 사용 여부
	// 사용하지 않기로 결정 ( 2017학년도 1학기 )
	private static final boolean USE_NEUTRALITY = false;


	/*********************************************************************************/
	/*********************************************************************************/


	public static final int PLAYER_1 = 0;
	public static final int PLAYER_2 = 1;
	public static final int PLAYER_3 = 2;
	public static final int PLAYER_4 = 3;
	public static final int PLAYER_5 = 4;

	public static final int MONEY_10K = 0;
	public static final int MONEY_20K = 1;
	public static final int MONEY_30K = 2;
	public static final int MONEY_40K = 3;
	public static final int MONEY_50K = 4;
	public static final int MONEY_60K = 5;
	public static final int MONEY_70K = 6;
	public static final int MONEY_80K = 7;
	public static final int MONEY_90K = 8;

	public static final int CASINO_1 = 0;
	public static final int CASINO_2 = 1;
	public static final int CASINO_3 = 2;
	public static final int CASINO_4 = 3;
	public static final int CASINO_5 = 4;
	public static final int CASINO_6 = 5;


	/*********************************************************************************/
	/*********************************************************************************/


	static final int NUM_PLAYER_SLOTS = 5;
	static final int NUM_MONEY_SLOTS  = 5;
	static final int NUM_CASINO_SLOTS = 6;

	static final Color PANEL_BACKGROUND  = new Color( 0x002000 ); // 판 배경
	static final Color DICE_BORDER_COLOR = new Color( 0xFFFFFF );

	static final int IDX_BACKGROUND = 0;
	static final int IDX_FOREGROUND = 1;

	static final Color[][] PLAYER_COLOR_SET = new Color[][] {

		{ new Color( 0x770000 ), new Color( 0xFFFFFF ) },
		{ new Color( 0x007700 ), new Color( 0xFFFFFF ) },
		{ new Color( 0x000077 ), new Color( 0xFFFFFF ) },
		{ new Color( 0x222222 ), new Color( 0xFFFFFF ) },
		{ new Color( 0xFFFFFF ), new Color( 0x000000 ) },
	};

	static final String[] MONEY_STRING_SET = new String[] {

			"$10,000",
			"$20,000",
			"$30,000",
			"$40,000",
			"$50,000",
			"$60,000",
			"$70,000",
			"$80,000",
			"$90,000"
	};

	static final Color[] MONEY_COLOR_SET = new Color[] {

			new Color( 0xFFFF00 + 240 ), // $10,000
			new Color( 0xFFFF00 + 210 ), // $20,000
			new Color( 0xFFFF00 + 180 ), // $30,000
			new Color( 0xFFFF00 + 150 ), // $40,000
			new Color( 0xFFFF00 + 120 ), // $50,000
			new Color( 0xFFFF00 +  90 ), // $60,000
			new Color( 0xFFFF00 +  60 ), // $70,000
			new Color( 0xFFFF00 +  30 ), // $80,000
			new Color( 0xFFFF00 +   0 )  // $90,000
	};

	static final String[] CASINO_NAME_SET = new String[] {

			"1. 서울",
			"2. 대전",
			"3. 대구",
			"4. 부산",
			"5. 광주",
			"6. 천안"
	};


	/*************************************************************************/
	/*************************************************************************/


	boolean useNeutrality;

	private void useNeutrality( boolean useNeutrality ) {

		if( useNeutrality ) {
			for( int cn = CASINO_1; cn <= CASINO_6; cn ++ ) {
				CasinoBattingPanel battingPanel = gamePanel.casinos[ cn ].battingPanel;

				battingPanel.whiteEnabled = true;
				battingPanel.containers[ PLAYER_5 ].setVisible( true );
				battingPanel.revalidate();
				battingPanel.repaint();
			}
			StatePlayerLabel[] playerLabels = gamePanel.statePanel.playerLabels;
			for( int pn = PLAYER_1; pn <= PLAYER_4; pn ++ ) {
				JLabel remainDices = playerLabels[ pn ].remainDices;

				remainDices.setText( "0-0" );
				remainDices.revalidate();
				remainDices.repaint();
			}
		}

		else {
			for( int cn = CASINO_1; cn <= CASINO_6; cn ++ ) {
				CasinoBattingPanel battingPanel = gamePanel.casinos[ cn ].battingPanel;

				battingPanel.whiteEnabled = false;
				battingPanel.containers[ PLAYER_5 ].setVisible( false );
				battingPanel.revalidate();
				battingPanel.repaint();
			}
			StatePlayerLabel[] playerLabels = gamePanel.statePanel.playerLabels;
			for( int pn = PLAYER_1; pn <= PLAYER_4; pn ++ ) {
				JLabel remainDices = playerLabels[ pn ].remainDices;

				remainDices.setText( "0" );
				remainDices.revalidate();
				remainDices.repaint();
			}
		}

		this.useNeutrality = useNeutrality;
	}


	/*************************************************************************/
	/*************************************************************************/


	final VegasGamePanel gamePanel;

	private BattingBlinkThread battingBlinkOwnThr;
	private BattingBlinkThread battingBlinkNeuThr;

	private PlayerBlinkThread[] playerBlinkThrs;

	private int lineNum;

	private BanConfirmPanelThread banConfThr;

	private boolean screen;

	public VegasFrame() {

		VegasResource.registerFont( "vegas/gui/res/font_consolas.ttf" );
		VegasResource.registerFont( "vegas/gui/res/font_malgun.ttf" );

		gamePanel = new VegasGamePanel();

		playerBlinkThrs = new PlayerBlinkThread[ NUM_PLAYER_SLOTS - 1 ];


		// 카지노 패널 고정값 설정
		for( int cn = CASINO_1; cn <= CASINO_6; cn ++ ) {

			CasinoPanel casino = gamePanel.casinos[ cn ];
			casino.nameLabel.setText( CASINO_NAME_SET[ cn ] );

			// 배팅 레이블 고정값 설정
			JPanel[] containers = casino.battingPanel.containers;
			for( int pn = PLAYER_1; pn <= PLAYER_5; pn ++ ) {

				Component comp = containers[ pn ].getComponent( 0 );
				CasinoBattingLabel battingLabel = ( CasinoBattingLabel )comp;

				battingLabel.playerNum = pn;
				battingLabel.diceShape.number = cn + 1;
				battingLabel.diceShape.background = PLAYER_COLOR_SET[ pn ][ IDX_BACKGROUND ];
				battingLabel.diceShape.foreground = PLAYER_COLOR_SET[ pn ][ IDX_FOREGROUND ];
			}
		}

		// 플레이어 레이블 고정값 설정
		for( int pn = PLAYER_1; pn <= PLAYER_4; pn ++ ) {
			StatePlayerLabel[] playerLabels = gamePanel.statePanel.playerLabels;
			playerLabels[ pn ].setBackground( PLAYER_COLOR_SET[ pn ][ IDX_BACKGROUND ] );
			playerLabels[ pn ].playerNum = pn;
		}


		this.setIconImage( VegasResource.loadImage( "vegas/gui/res/logo.png" ) );
		this.setTitle( "라스베가스 게임서버앱" );
		this.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

		this.setContentPane( gamePanel );
		this.useNeutrality( USE_NEUTRALITY );

		this.setScreen( true );
		this.logClearLines();
		this.removeAllBattings();
		this.removeAllBattingBlinks();
		this.removeAllMoneys();
		this.setMessage( "" );
		this.showMessage();
		this.setRound( 0, 2 );
		this.removeAllPlayerNames();
		this.removeAllPlayerDices();
		this.removeAllPlayerMoneys();
		this.setAddressFields( "IP주소", "Port번호" );
		this.setOpenedState( false );

		GraphicsEnvironment gEnv = GraphicsEnvironment.getLocalGraphicsEnvironment();
		Rectangle maxBounds = gEnv.getMaximumWindowBounds();

		int minW  = 800;
		int minH  = 600;
		int initX = maxBounds.x + ( maxBounds.width  - minW ) / 2;
		int initY = maxBounds.y + ( maxBounds.height - minH ) / 2;

		this.setLocation( initX, initY );
		this.setMinimumSize( new Dimension( minW, minH ) );
	}


	/*********************************************************************************/
	/*********************************************************************************/


	private void validatePlayer( int num ) {

		switch( num ) {

		case PLAYER_1 :
		case PLAYER_2 :
		case PLAYER_3 :
		case PLAYER_4 :
		case PLAYER_5 : return;

		default : throw new RuntimeException( "잘못된 플레이어 번호입니다." );

		}
	}

	private void validateRealPlayer( int num ) {

		switch( num ) {

		case PLAYER_1 :
		case PLAYER_2 :
		case PLAYER_3 :
		case PLAYER_4 : return;

		default : throw new RuntimeException( "잘못된 플레이어 번호입니다." );

		}
	}

	private void validateMoney( int amount ) {

		switch( amount ) {

		case MONEY_10K :
		case MONEY_20K :
		case MONEY_30K :
		case MONEY_40K :
		case MONEY_50K :
		case MONEY_60K :
		case MONEY_70K :
		case MONEY_80K :
		case MONEY_90K : return;

		default : throw new RuntimeException( "잘못된 금액 양입니다." );

		}
	}

	private void validateCasino( int num ) {

		switch( num ) {

		case CASINO_1 :
		case CASINO_2 :
		case CASINO_3 :
		case CASINO_4 :
		case CASINO_5 :
		case CASINO_6 : return;

		default : throw new RuntimeException( "잘못된 카지노 번호입니다." );

		}
	}

	private void validateDice( int num ) {

		switch( num ) {

		case 1 :
		case 2 :
		case 3 :
		case 4 :
		case 5 :
		case 6 : return;

		default : throw new RuntimeException( "잘못된 주사위 번호입니다." );

		}
	}

	private void validateRound( int current, int max ) {

		if( current < 0 || max < 0 || max < current ) {
			throw new RuntimeException( "잘못된 라운드 값입니다." );
		}
	}


	/*************************************************************************/
	/*************************************************************************/


	public void setScreen( boolean screen ) {

		if( screen ) {
			StatePanel statePanel = gamePanel.statePanel;

			statePanel.resultPanel.setVisible( false );
			statePanel.roundLabel.setVisible( false );
			for( int cn = VegasFrame.CASINO_1; cn <= VegasFrame.CASINO_6; cn ++ ) {
				gamePanel.casinos[ cn ].setVisible( false );
			}
			for( int pn = VegasFrame.PLAYER_1; pn <= VegasFrame.PLAYER_4; pn ++ ) {
				statePanel.playerLabels[ pn ].setVisible( false );
			}

			statePanel.ipField.setVisible( true );
			statePanel.portField.setVisible( true );
			statePanel.openCloseServer.setVisible( true );
			statePanel.clearLog.setVisible( true );
			statePanel.gameSpeed.setVisible( true );
			gamePanel.logPanel.setVisible( true );

			gamePanel.revalidate();
			gamePanel.repaint();

			statePanel.ipField.requestFocus(); 
		}
		else {
			StatePanel statePanel = gamePanel.statePanel;

			statePanel.ipField.setVisible( false );
			statePanel.portField.setVisible( false );
			statePanel.openCloseServer.setVisible( false );
			statePanel.clearLog.setVisible( false );
			statePanel.gameSpeed.setVisible( false );
			gamePanel.logPanel.setVisible( false );

			statePanel.resultPanel.setVisible( true );
			statePanel.roundLabel.setVisible( true );
			for( int cn = VegasFrame.CASINO_1; cn <= VegasFrame.CASINO_6; cn ++ ) {
				gamePanel.casinos[ cn ].setVisible( true );
			}
			for( int pn = VegasFrame.PLAYER_1; pn <= VegasFrame.PLAYER_4; pn ++ ) {
				statePanel.playerLabels[ pn ].setVisible( true );
			}

			gamePanel.revalidate();
			gamePanel.repaint();
		}	

		this.screen = screen;
	}

	public boolean getScreen() {

		return screen;
	}

	public void logNewLine( String line ) {

		if( line == null ) {
			throw new RuntimeException( "한 줄이 없습니다." );
		}

		if( lineNum > 999 ) {
			this.logClearLines();
		}

		String lineNumStr = String.format( "%4d", lineNum );

		gamePanel.logPanel.txtArea.append( lineNumStr + "  -  " + line + "\n" );
		gamePanel.logPanel.txtArea.revalidate();
		gamePanel.logPanel.txtArea.repaint();

		lineNum ++;
	}

	public void logClearLines() {

		gamePanel.logPanel.txtArea.setText( null );
		gamePanel.logPanel.txtArea.revalidate();
		gamePanel.logPanel.txtArea.repaint();

		lineNum = 1;
	}

	public void addMoney( int casinoNum, int moneyAmount ) {

		validateCasino( casinoNum );
		validateMoney( moneyAmount );

		JPanel[] containers = gamePanel.casinos[ casinoNum ].moneyPanel.containers;
		ArrayList<CasinoMoneyLabel> arrList = new ArrayList<CasinoMoneyLabel>();
		for( int ms = 0; ms < NUM_MONEY_SLOTS; ms ++ ) {
			int ccount = containers[ ms ].getComponentCount();
			if( ccount == 1 ) {
				arrList.add( ( CasinoMoneyLabel )containers[ ms ].getComponent( 0 ) );
				containers[ ms ].removeAll();
			}
		}

		if( arrList.size() == NUM_MONEY_SLOTS ) {
			for( int i = 0; i < NUM_MONEY_SLOTS; i ++ ) {
				containers[ i ].add( arrList.get( i ) );
			}
			return;
		}
		else {
			CasinoMoneyLabel newMoneyLabel = new CasinoMoneyLabel();
			newMoneyLabel.amount = moneyAmount;
			newMoneyLabel.setText( MONEY_STRING_SET[ moneyAmount ] );
			newMoneyLabel.setBackground( MONEY_COLOR_SET[ moneyAmount ] );
			arrList.add( newMoneyLabel );
		}

		arrList.sort( new Comparator<CasinoMoneyLabel>() {

			@Override
			public int compare( CasinoMoneyLabel o1, CasinoMoneyLabel o2 ) {

				return o2.amount - o1.amount;
			}
		});

		for( int i = 0; i < arrList.size(); i ++ ) {
			containers[ i ].add( arrList.get( i ) );
			containers[ i ].revalidate();
			containers[ i ].repaint();
		}
	}

	private class BattingBlinkThread extends Thread {

		private final CasinoBattingLabel lbl;

		private BattingBlinkThread( CasinoBattingLabel lbl ) {

			this.lbl = lbl;
		}

		boolean lastVisible = false;

		@Override
		public void run() {

			try {
				while( true ) {

					lbl.setVisible( false );
					sleep( 150 );

					lbl.setVisible( true );
					sleep( 700 );
				}
			}
			catch( InterruptedException ex ) {

				lbl.setVisible( lastVisible );
			}
		}
	}

	public void addBatting( int casinoNum, int playerNum, int count, boolean blink ) {

		validateCasino( casinoNum );
		validatePlayer( playerNum );

		JPanel[] containers = gamePanel.casinos[ casinoNum ].battingPanel.containers;
		ArrayList<CasinoBattingLabel> arrList = new ArrayList<CasinoBattingLabel>();
		for( int pn = PLAYER_1; pn <= PLAYER_5; pn ++ ) {

			Component comp = containers[ pn ].getComponent( 0 );
			CasinoBattingLabel battingLabel = ( CasinoBattingLabel )comp;
			containers[ pn ].removeAll();
			arrList.add( battingLabel );

			if( battingLabel.playerNum == playerNum ) {

				if( playerNum == PLAYER_5 && !useNeutrality ) {
					battingLabel.count = 0;
				}
				else if( playerNum == PLAYER_5 && useNeutrality ) {
					battingLabel.count += count;
					if( battingLabel.count < 0 ) {
						battingLabel.count = 0;
					}
					else if( battingLabel.count > 99 ) {
						battingLabel.count = 99;
					}

					if( battingBlinkNeuThr != null ) {
						battingBlinkNeuThr.lastVisible = true;
						battingBlinkNeuThr.interrupt();
					}
					if( blink ) {
						battingBlinkNeuThr = new BattingBlinkThread( battingLabel );
						battingBlinkNeuThr.start();
					}
				}
				else {
					battingLabel.count += count;
					if( battingLabel.count < 0 ) {
						battingLabel.count = 0;
					}
					else if( battingLabel.count > 99 ) {
						battingLabel.count = 99;
					}

					if( battingBlinkOwnThr != null ) {
						battingBlinkOwnThr.lastVisible = true;
						battingBlinkOwnThr.interrupt();
					}
					if( blink ) {
						battingBlinkOwnThr = new BattingBlinkThread( battingLabel );
						battingBlinkOwnThr.start();
					}
				}

				if( battingLabel.count == 0 ) {
					battingLabel.diceShape.setVisible( false );
					battingLabel.countLabel.setText( null );
				}
				else if( battingLabel.count == 1 ) {
					battingLabel.diceShape.setVisible( true );
					battingLabel.countLabel.setText( null );
				}
				else {
					battingLabel.diceShape.setVisible( true );
					battingLabel.countLabel.setText( "x" + battingLabel.count );
				}


				battingLabel.revalidate();
				battingLabel.repaint();
			}
		}

		arrList.sort( new Comparator<CasinoBattingLabel>() {

			@Override
			public int compare( CasinoBattingLabel o1, CasinoBattingLabel o2 ) {

				int val = o2.count - o1.count;
				if( val != 0 ) {
					return val;
				}
				else {
					return o1.playerNum - o2.playerNum; 
				}
			}
		});

		for( int i = 0; i < arrList.size(); i ++ ) {
			containers[ i ].add( arrList.get( i ) );
			containers[ i ].revalidate();
			containers[ i ].repaint();
		}
	}

	public void removeAllMoneys() {

		for( int cn = CASINO_1; cn <= CASINO_6; cn ++ ) {
			JPanel[] containers = gamePanel.casinos[ cn ].moneyPanel.containers;

			for( int ms = 0; ms < NUM_MONEY_SLOTS; ms ++ ) {
				int ccount = containers[ ms ].getComponentCount();
				if( ccount == 1 ) {
					containers[ ms ].removeAll();
					containers[ ms ].revalidate();
					containers[ ms ].repaint();
				}
			}
		}
	}

	public void removeAllBattings() {

		for( int cn = CASINO_1; cn <= CASINO_6; cn ++ ) {
			JPanel[] containers = gamePanel.casinos[ cn ].battingPanel.containers;

			for( int pn = PLAYER_1; pn <= PLAYER_5; pn ++ ) {
				Component comp = containers[ pn ].getComponent( 0 );;
				CasinoBattingLabel battingLabel = ( CasinoBattingLabel )comp;

				battingLabel.count = 0;
				battingLabel.countLabel.setText( null );
				battingLabel.diceShape.setVisible( false );
				battingLabel.revalidate();
				battingLabel.repaint();
			}
		}
	}

	public void removeAllBattingBlinks() {

		if( battingBlinkOwnThr != null ) {
			battingBlinkOwnThr.lastVisible = true;
			battingBlinkOwnThr.interrupt();
		}
		if( battingBlinkNeuThr != null ) {
			battingBlinkNeuThr.lastVisible = true;
			battingBlinkNeuThr.interrupt();
		}
	}

	private class BanConfirmPanelThread extends Thread {

		private final int msec;

		private BanConfirmPanelThread( int msec, String txt, int playerNum ) {

			this.msec = msec;

			StatePanel statePanel = gamePanel.statePanel;
			BanConfirmPanel banConfirmPanel = statePanel.banConfirmPanel;

			if( playerNum == -1 ) {
				banConfirmPanel.yesBtn.setVisible( false );
				banConfirmPanel.noBtn.setVisible( false );
			}
			else {	
				banConfirmPanel.playerNum = playerNum;
				banConfirmPanel.yesBtn.setVisible( true );
				banConfirmPanel.noBtn.setVisible( true );
			}

			banConfirmPanel.lbl.setText( txt );
			statePanel.banConfirmPanelOn = true;
			statePanel.revalidate();
			statePanel.repaint();
		}

		@Override
		public void run() {

			try {
				sleep( msec );
				StatePanel statePanel = gamePanel.statePanel;
				statePanel.banConfirmPanelOn = false;
				statePanel.revalidate();
				statePanel.repaint();
				banConfThr = null;
			}
			catch( Exception ex ) {}
		}
	}

	public void showBanConfirmPanel( int msec, String txt ) {

		if( banConfThr != null ) {
			banConfThr.interrupt();
		}
		banConfThr = new BanConfirmPanelThread( msec, txt, -1 );
		banConfThr.start();
	}

	public void showBanConfirmPanel( int msec, String txt, int playerNum ) {

		validateRealPlayer( playerNum );

		if( banConfThr != null ) {
			banConfThr.interrupt();
		}
		banConfThr = new BanConfirmPanelThread( msec, txt, playerNum );
		banConfThr.start();
	}

	public void showMessage() {

		gamePanel.statePanel.diceRollPanel.setVisible( false );
		gamePanel.statePanel.messagePanel.setVisible( true );
	}

	public void setMessage( String msg ) {

		gamePanel.statePanel.messagePanel.setText( msg );
	}

	public void showRollResult() {

		gamePanel.statePanel.messagePanel.setVisible( false );
		gamePanel.statePanel.diceRollPanel.setVisible( true );
	}

	public void addRollResult( int playerNum, int diceNum ) {

		validatePlayer( playerNum );
		validateDice( diceNum );

		DiceShape shape = new DiceShape();
		shape.number = diceNum;
		shape.background = PLAYER_COLOR_SET[ playerNum ][ IDX_BACKGROUND ];
		shape.foreground = PLAYER_COLOR_SET[ playerNum ][ IDX_FOREGROUND ];

		JPanel rolls = gamePanel.statePanel.diceRollPanel.rolls;
		rolls.add( shape );
		rolls.revalidate();
		rolls.repaint();
	}

	public void removeAllRollResults() {

		JPanel rolls = gamePanel.statePanel.diceRollPanel.rolls;
		rolls.removeAll();
		rolls.revalidate();
		rolls.repaint();
	}

	public void setRound( int current, int max ) {

		validateRound( current, max );

		JLabel roundLabel = gamePanel.statePanel.roundLabel;
		roundLabel.setText( current + "/" + max );
		roundLabel.revalidate();
		roundLabel.repaint();
	}

	public void setPlayerName( int playerNum, String name ) {

		validateRealPlayer( playerNum );

		if( name == null ) {
			removePlayerName( playerNum );
			return;
		}

		JLabel playerName = gamePanel.statePanel.playerLabels[ playerNum ].playerName;
		playerName.setText( name );
		playerName.revalidate();
		playerName.repaint();
	}

	public void removePlayerName( int playerNum ) {

		validateRealPlayer( playerNum );

		JLabel playerName = gamePanel.statePanel.playerLabels[ playerNum ].playerName;
		playerName.setText( "" );
		playerName.revalidate();
		playerName.repaint();
	}

	public void removeAllPlayerNames() {

		for( int pn = PLAYER_1; pn <= PLAYER_4; pn ++ ) {
			removePlayerName( pn );
		}
	}

	public void setPlayerDices( int playerNum, int ownCount, int neutralityCount ) {

		validateRealPlayer( playerNum );

		JLabel remainDices = gamePanel.statePanel.playerLabels[ playerNum ].remainDices;

		if( ownCount < 0 ) {
			ownCount = 0;
		}
		else if( ownCount > 9 ) {
			ownCount = 9;
		}

		if( useNeutrality ) {

			if( neutralityCount < 0 ) {
				neutralityCount = 0;
			}
			else if( neutralityCount > 9 ) {
				neutralityCount = 9;
			}

			remainDices.setText( ownCount + "-" + neutralityCount );
			remainDices.revalidate();
			remainDices.repaint();
		}
		else {
			remainDices.setText( "" + ownCount );
			remainDices.revalidate();
			remainDices.repaint();
		}
	}

	public void removePlayerDices( int playerNum ) {

		validateRealPlayer( playerNum );

		JLabel remainDices = gamePanel.statePanel.playerLabels[ playerNum ].remainDices;

		if( useNeutrality ) {
			remainDices.setText( "0-0" );
			remainDices.revalidate();
			remainDices.repaint();
		}
		else {
			remainDices.setText( "0" );
			remainDices.revalidate();
			remainDices.repaint();
		}
	}

	public void removeAllPlayerDices() {

		for( int pn = PLAYER_1; pn <= PLAYER_4; pn ++ ) {
			removePlayerDices( pn );
		}
	}

	public void setPlayerMoney( int playerNum, int moneyAmount ) {

		validateRealPlayer( playerNum );

		if( moneyAmount == 0 ) {
			JLabel moneyCover = gamePanel.statePanel.playerLabels[ playerNum ].moneyCover;
			moneyCover.setText( "$0" );
			moneyCover.revalidate();
			moneyCover.repaint();
		}
		else if( moneyAmount % 10000 == 0 ) {
			JLabel moneyCover = gamePanel.statePanel.playerLabels[ playerNum ].moneyCover;
			moneyCover.setText( "$" + ( moneyAmount / 1000 ) + ",000" );
			moneyCover.revalidate();
			moneyCover.repaint();
		}
	}

	public void removeAllPlayerMoneys() {

		for( int pn = PLAYER_1; pn <= PLAYER_4; pn ++ ) {
			setPlayerMoney( pn, 0 );
		}
	}

	private class PlayerBlinkThread extends Thread {

		private final JLabel highlight;

		private PlayerBlinkThread( int playerNum ) {

			highlight = gamePanel.statePanel.playerLabels[ playerNum ].highlight;
		}

		private boolean finishState;

		@Override
		public void run() {

			try {
				while( true ) {

					highlight.setOpaque( true );
					highlight.revalidate();
					highlight.repaint();
					sleep( 200 );

					highlight.setOpaque( false );
					highlight.revalidate();
					highlight.repaint();
					sleep( 200 );
				}
			}
			catch( InterruptedException ex ) {

				highlight.setOpaque( finishState );
				highlight.revalidate();
				highlight.repaint();
			}
		}
	}

	public void focusPlayer( int playerNum ) {

		validateRealPlayer( playerNum );

		if( playerBlinkThrs[ playerNum ] != null ) {
			playerBlinkThrs[ playerNum ].finishState = true;
			playerBlinkThrs[ playerNum ].interrupt();
			playerBlinkThrs[ playerNum ] = null;
		}

		JLabel highlight = gamePanel.statePanel.playerLabels[ playerNum ].highlight;
		highlight.setOpaque( true );
		highlight.revalidate();
		highlight.repaint();
	}

	public void blinkPlayer( int playerNum ) {

		validateRealPlayer( playerNum );

		if( playerBlinkThrs[ playerNum ] == null ) {
			playerBlinkThrs[ playerNum ] = new PlayerBlinkThread( playerNum );
			playerBlinkThrs[ playerNum ].start();
		}
	}

	public void removePlayerHighlight( int playerNum ) {

		validateRealPlayer( playerNum );

		if( playerBlinkThrs[ playerNum ] != null ) {
			playerBlinkThrs[ playerNum ].finishState = false;
			playerBlinkThrs[ playerNum ].interrupt();
			playerBlinkThrs[ playerNum ] = null;
		}

		JLabel highlight = gamePanel.statePanel.playerLabels[ playerNum ].highlight;
		highlight.setOpaque( false );
		highlight.revalidate();
		highlight.repaint();
	}

	public void removeAllPlayerHighlights() {

		for( int pn = PLAYER_1; pn <= PLAYER_4; pn ++ ) {
			removePlayerHighlight( pn );
		}
	}

	public void setAddressFields( String ip, String port ) {

		StatePanel statePanel = gamePanel.statePanel;

		statePanel.ipField.setText( ip );
		statePanel.portField.setText( port );
		statePanel.revalidate();
		statePanel.repaint();
	}

	public String getFieldOfIP() {

		return gamePanel.statePanel.ipField.getText();
	}

	public String getFieldOfPort() {

		return gamePanel.statePanel.portField.getText();
	}

	public void setOpenedState( boolean val ) {

		StatePanel statePanel = gamePanel.statePanel;

		if( val ) {
			statePanel.ipField.setEditable( false );
			statePanel.portField.setEditable( false );
			statePanel.ipField.setBackground( new Color( 160, 160, 160 ) );
			statePanel.portField.setBackground( new Color( 160, 160, 160 ) );
			statePanel.ipField.setFocusable( false );
			statePanel.portField.setFocusable( false );
			statePanel.openCloseServer.setText( "서버 닫기" );
			statePanel.revalidate();
			statePanel.repaint();
		}
		else {
			statePanel.ipField.setEditable( true );
			statePanel.portField.setEditable( true );
			statePanel.ipField.setBackground( new Color( 240, 240, 240 ) );
			statePanel.portField.setBackground( new Color( 240, 240, 240 ) );
			statePanel.ipField.setFocusable( true );
			statePanel.portField.setFocusable( true );
			statePanel.openCloseServer.setText( "서버 열기" );
			statePanel.revalidate();
			statePanel.repaint();
			statePanel.ipField.requestFocus();
		}
	}

	public void setOpenCloseServerListener( VegasListener lis ) {

		gamePanel.statePanel.openCloseServerListener = lis;
	}
	
	public void setGameSpeedListener( VegasListener lis ) {
	
		gamePanel.statePanel.gameSpeedListener = lis;
	}

	public void setClearLogListener( VegasListener lis ) {

		gamePanel.statePanel.clearLogListener = lis;
	}

	public void setSwitchScreenListener( VegasListener lis ) {

		gamePanel.statePanel.switchScreenListener = lis;
	}

	public void setClickPlayerListener( int playerNum, VegasListener lis ) {

		validateRealPlayer( playerNum );

		gamePanel.statePanel.clickPlayerListener[ playerNum ] = lis;
	}

	public void setBanPlayerListener( int playerNum, VegasListener lis ) {

		validateRealPlayer( playerNum );

		gamePanel.statePanel.banConfirmPanel.banPlayerListener[ playerNum ] = lis;
	}
}
