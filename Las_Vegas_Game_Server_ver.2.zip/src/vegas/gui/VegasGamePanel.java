
package vegas.gui;

import java.awt.*;
import javax.swing.*;

class VegasGamePanel extends JPanel {

	private static final long serialVersionUID = 9093838495074440600L;

	private static final int NUM_CASINO_SLOTS = VegasFrame.NUM_CASINO_SLOTS;

	final CasinoPanel[] casinos;

	final LogPanel logPanel;

	final StatePanel statePanel;

	VegasGamePanel() {

		casinos = new CasinoPanel[ NUM_CASINO_SLOTS ];
		for( int i = 0; i < NUM_CASINO_SLOTS; i ++ ) {

			casinos[ i ] = new CasinoPanel();
			this.add( casinos[ i ] );
		}

		logPanel = new LogPanel();
		logPanel.setVisible( false );
		this.add( logPanel );

		statePanel = new StatePanel();
		statePanel.setBackground( VegasFrame.PANEL_BACKGROUND );
		this.add( statePanel );

		this.setBackground( Color.WHITE );
		this.setLayout( new LayoutManager() {

			@Override
			public void addLayoutComponent( String name, Component comp ) {}

			@Override
			public void removeLayoutComponent( Component comp ) {}

			@Override
			public Dimension preferredLayoutSize( Container parent ) { return null; }

			@Override
			public Dimension minimumLayoutSize( Container parent ) { return null; }

			@Override
			public void layoutContainer( Container parent ) {

				int pw = parent.getWidth();
				int ph = parent.getHeight();

				int mw = pw / 160;
				int mh = ph / 160;

				int x = mw;
				int y = mh;
				int w = ( pw - 4 * x ) / 3;
				int r = ( pw - 4 * x ) % 3;
				int h = ( ( ph * 6 / 7 ) - 3 * y ) / 2;

				// 고정 인덱스
				casinos[ 0 ].setBounds( x, y, w, h );
				x += mw + w;
				casinos[ 1 ].setBounds( x, y, w, h );
				x += mw + w;
				casinos[ 2 ].setBounds( x, y, w + r, h );
				x = mw;
				y += mh + h;
				casinos[ 3 ].setBounds( x, y, w, h );
				x += mw + w;
				casinos[ 4 ].setBounds( x, y, w, h );
				x += mw + w;
				casinos[ 5 ].setBounds( x, y, w + r, h );

				int hh = ph - ph * 6 / 7 - mh;
				hh = ( hh - ( hh / 20 ) ) / 2;

				logPanel.setBounds( mw, mh, pw - 2 * mw, 2 * h + 2 * mh + hh );

				w = pw - 2 * mw;
				h = ph - ph * 6 / 7 - mh;
				x = mw;
				y = ph - h - mh;

				statePanel.setBounds( x, y, w, h );
			}
		});
	}
}
