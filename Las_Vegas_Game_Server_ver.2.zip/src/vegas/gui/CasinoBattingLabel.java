
package vegas.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class CasinoBattingLabel extends JPanel {

	private static final long serialVersionUID = 820798159711966182L;

	final DiceShape diceShape;

	final JLabel countLabel;

	int playerNum;

	int count;

	CasinoBattingLabel() {

		diceShape = new DiceShape();

		countLabel = new JLabel();
		countLabel.setForeground( Color.YELLOW );
		countLabel.setHorizontalAlignment( JLabel.RIGHT );
		countLabel.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int h = countLabel.getHeight();

				int fs = h * 3 / 5;

				countLabel.setFont( new Font( "맑은 고딕", Font.BOLD, fs ) );
			}
		});

		this.setOpaque( false );
		this.add( diceShape  );
		this.add( countLabel );
		this.setLayout( new LayoutManager() {

			@Override
			public void addLayoutComponent( String name, Component comp ) {}

			@Override
			public void removeLayoutComponent( Component comp ) {}

			@Override
			public Dimension preferredLayoutSize( Container parent ) { return null; }

			@Override
			public Dimension minimumLayoutSize( Container parent ) { return null; }

			@Override
			public void layoutContainer( Container parent ) {

				int pw = parent.getWidth();
				int ph = parent.getHeight();

				int x1 = 0;
				int y1 = 0;
				int w1 = ph;
				int h1 = w1;

				diceShape.setBounds( x1, y1, w1, h1 );

				int x2 = x1 + w1;
				int y2 = y1;
				int w2 = pw - w1;
				int h2 = h1;

				countLabel.setBounds( x2, y2, w2, h2 );
			}
		});
	}
}
