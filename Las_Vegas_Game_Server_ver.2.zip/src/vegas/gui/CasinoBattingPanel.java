
package vegas.gui;

import java.awt.*;
import javax.swing.*;

class CasinoBattingPanel extends JPanel {

	private static final long serialVersionUID = 2945423940324076413L;

	private static final int NUM_PLAYER_SLOTS = VegasFrame.NUM_PLAYER_SLOTS;

	final JPanel[] containers;

	boolean whiteEnabled;

	CasinoBattingPanel() {

		containers = new JPanel[ NUM_PLAYER_SLOTS ];
		for( int i = 0; i < NUM_PLAYER_SLOTS; i ++ ) {

			containers[ i ] = new JPanel();
			containers[ i ].setOpaque( false );
			containers[ i ].setLayout( new BorderLayout() );
			containers[ i ].add( new CasinoBattingLabel() );

			this.add( containers[ i ] );
		}

		this.setOpaque( false );
		this.setLayout( new LayoutManager() {

			@Override
			public void addLayoutComponent( String name, Component comp ) {}

			@Override
			public void removeLayoutComponent( Component comp ) {}

			@Override
			public Dimension preferredLayoutSize( Container parent ) { return null; }

			@Override
			public Dimension minimumLayoutSize( Container parent ) { return null; }

			@Override
			public void layoutContainer( Container parent ) {

				int s = -1;
				if( whiteEnabled ) {
					s = NUM_PLAYER_SLOTS;
				}
				else {
					s = NUM_PLAYER_SLOTS - 1;
				}

				int pw = parent.getWidth();
				int ph = parent.getHeight();

				int mw = pw / 25;
				int mh = ph / 25;

				int x = mw;
				int y = mh;
				int w = ( pw - 3 * mw );
				int h = ( ph - ( s + 1 ) * mh ) / s;

				for( int i = 0; i < s; i ++ ) {
					containers[ i ].setBounds( x, y, w, h );
					y += mh + h;
				}
			}
		});
	}
}
