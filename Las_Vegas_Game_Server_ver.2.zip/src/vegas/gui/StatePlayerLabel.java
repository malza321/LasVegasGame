
package vegas.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class StatePlayerLabel extends JPanel {

	private static final long serialVersionUID = 1416581403315693739L;

	private final StatePlayerLabel ref;

	final JLabel moneyCover;
	final JLabel highlight;
	final JLabel playerName;
	final JLabel remainDices;

	int playerNum;

	StatePlayerLabel() {

		ref = this;

		moneyCover = new JLabel( "$100,000" );
		moneyCover.setHorizontalAlignment( JLabel.LEFT );
		moneyCover.setForeground( Color.YELLOW );
		moneyCover.setVisible( false );
		moneyCover.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int w = ref.getWidth();
				int h = ref.getHeight();

				moneyCover.setFont( new Font( "맑은 고딕", Font.BOLD, h * 5 / 9 ) );
				moneyCover.setBorder( new EmptyBorder( 0, w / 24, 0, w / 24 ) );
			}
		});

		highlight = new JLabel();
		highlight.setBackground( Color.YELLOW );

		playerName = new JLabel();
		playerName.setHorizontalAlignment( JLabel.LEFT );
		playerName.setForeground( Color.WHITE );
		playerName.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int w = ref.getWidth();
				int h = ref.getHeight();

				playerName.setFont( new Font( "맑은 고딕", Font.BOLD, h * 3 / 7 ) );
				playerName.setBorder( new EmptyBorder( 0, w / 24, 0, w / 24 ) );
			}
		});

		remainDices = new JLabel();
		remainDices.setHorizontalAlignment( JLabel.CENTER );
		remainDices.setForeground( Color.WHITE );
		remainDices.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int fs = ref.getHeight() * 4 / 7;

				remainDices.setFont( new Font( "맑은 고딕", Font.BOLD, fs ) );
			}
		});

		this.setCursor( new Cursor( Cursor.HAND_CURSOR ) );
		this.addMouseListener( new MouseAdapter() {

			@Override
			public void mouseEntered( MouseEvent ev ) {

				Color bg = VegasFrame.PLAYER_COLOR_SET[ playerNum ][ VegasFrame.IDX_BACKGROUND ];
				ref.setBackground( bg.brighter() );

				playerName.setVisible( false );
				moneyCover.setVisible( true );
			}

			@Override
			public void mouseExited( MouseEvent ev ) {

				Color bg = VegasFrame.PLAYER_COLOR_SET[ playerNum ][ VegasFrame.IDX_BACKGROUND ];
				ref.setBackground( bg );

				moneyCover.setVisible( false );
				playerName.setVisible( true );
			}

			@Override
			public void mousePressed( MouseEvent ev ) {

				StatePanel statePanel = ( StatePanel )ref.getParent();
				if( statePanel.clickPlayerListener[ playerNum ] != null ) {
					statePanel.clickPlayerListener[ playerNum ].action();
				}
			}
		});

		this.add( moneyCover );
		this.add( highlight );
		this.add( playerName );
		this.add( remainDices );
		this.setLayout( new LayoutManager() {

			@Override
			public void addLayoutComponent( String name, Component comp ) {}

			@Override
			public void removeLayoutComponent( Component comp ) {}

			@Override
			public Dimension preferredLayoutSize( Container parent ) { return null; }

			@Override
			public Dimension minimumLayoutSize( Container parent ) { return null; }

			@Override
			public void layoutContainer( Container parent ) {

				int pw = parent.getWidth();
				int ph = parent.getHeight();

				int w = remainDices.getPreferredSize().width + pw / 12;
				int h = ph;
				int x = pw - w;
				int y = 0;

				remainDices.setBounds( x, y, w, h );

				x = pw / 16;
				w = pw - w - x;

				playerName.setBounds( x, y, w, h );

				moneyCover.setBounds( x, y, w, h );

				w = x - ph / 10;
				h = ph - ph / 10 - ph / 10;
				x = ph / 10;
				y = x;

				highlight.setBounds( x, y, w, h );
			}
		});
	}
}
