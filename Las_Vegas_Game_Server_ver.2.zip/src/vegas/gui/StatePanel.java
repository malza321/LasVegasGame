
package vegas.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class StatePanel extends JPanel {

	private static final long serialVersionUID = -5803501697633536869L;

	private static final int NUM_PLAYER_SLOTS = VegasFrame.NUM_PLAYER_SLOTS;

	final BanConfirmPanel banConfirmPanel;

	boolean banConfirmPanelOn;

	final JLabel messagePanel;

	final StateResultPanel diceRollPanel;

	final JPanel resultPanel;

	final StateRoundLabel roundLabel;

	final StatePlayerLabel[] playerLabels;

	final JTextField ipField;
	final JTextField portField;

	final JLabel openCloseServer;
	final JLabel clearLog;
	final JLabel gameSpeed;
	final JLabel switchScreen;

	VegasListener   openCloseServerListener;
	VegasListener   clearLogListener;
	VegasListener   gameSpeedListener;
	VegasListener   switchScreenListener;
	VegasListener[] clickPlayerListener;

	StatePanel() {

		banConfirmPanel = new BanConfirmPanel();

		banConfirmPanelOn = false;

		this.add( banConfirmPanel );

		messagePanel = new JLabel();
		messagePanel.setForeground( Color.YELLOW );
		messagePanel.setOpaque( true );
		messagePanel.setBackground( VegasFrame.PANEL_BACKGROUND );
		messagePanel.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int h = messagePanel.getHeight();

				messagePanel.setFont( new Font( "맑은 고딕", Font.BOLD, h * 3 / 7 ) );
				messagePanel.setBorder( new EmptyBorder( 0, h / 3, 0, h / 3 ) );
			}
		});

		diceRollPanel = new StateResultPanel();

		resultPanel = new JPanel();
		resultPanel.add( messagePanel  );
		resultPanel.add( diceRollPanel );
		resultPanel.setLayout( new LayoutManager() {

			@Override
			public void addLayoutComponent( String name, Component comp ) {}

			@Override
			public void removeLayoutComponent( Component comp ) {}

			@Override
			public Dimension preferredLayoutSize( Container parent ) { return null; }

			@Override
			public Dimension minimumLayoutSize( Container parent ) { return null; }

			@Override
			public void layoutContainer( Container parent ) {

				int pw = parent.getWidth();
				int ph = parent.getHeight();

				messagePanel .setBounds( 0, 0, pw, ph );
				diceRollPanel.setBounds( 0, 0, pw, ph );
			}
		});

		this.add( resultPanel );

		roundLabel = new StateRoundLabel();

		this.add( roundLabel );

		playerLabels = new StatePlayerLabel[ NUM_PLAYER_SLOTS - 1 ];
		for( int i = 0; i < NUM_PLAYER_SLOTS - 1; i ++ ) {

			playerLabels[ i ] = new StatePlayerLabel();

			this.add( playerLabels[ i ] );
		}

		ipField = new JTextField();
		ipField.setHorizontalAlignment( JLabel.CENTER );
		ipField.setVisible( false );
		ipField.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int h = ipField.getHeight();
				ipField.setBorder( new CompoundBorder(
						new LineBorder( Color.BLACK, h / 10 ),
						new EmptyBorder( 0, h / 5, 0, h / 5 ) ) );
				ipField.setFont( new Font( "맑은 고딕", Font.BOLD, h * 2 / 5 ) );
			}
		});

		ipField.addFocusListener( new FocusListener() {

			@Override
			public void focusLost( FocusEvent ev ) {

				String txt = ipField.getText();
				if( txt.length() == 0 ) {
					ipField.setText( "IP주소" );
				}
			}

			@Override
			public void focusGained( FocusEvent ev ) {

				ipField.selectAll();
			}
		});

		this.add( ipField );

		portField = new JTextField();
		portField.setHorizontalAlignment( JLabel.CENTER );
		portField.setVisible( false );
		portField.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int h = portField.getHeight();
				portField.setBorder( new CompoundBorder(
						new LineBorder( Color.BLACK, h / 10 ),
						new EmptyBorder( 0, h / 5, 0, h / 5 ) ) );
				portField.setFont( new Font( "맑은 고딕", Font.BOLD, h * 2 / 5 ) );
			}
		});

		portField.addFocusListener( new FocusListener() {

			@Override
			public void focusLost( FocusEvent ev ) {

				String txt = portField.getText();
				if( txt.length() == 0 ) {
					portField.setText( "Port번호" );
				}
			}

			@Override
			public void focusGained( FocusEvent ev ) {

				portField.selectAll();
			}
		});

		this.add( portField );

		openCloseServer = new JLabel( "서버 열기" );
		openCloseServer.setHorizontalAlignment( JLabel.CENTER );
		openCloseServer.setOpaque( true );
		openCloseServer.setBackground( new Color( 180, 180, 180 ) );
		openCloseServer.setVisible( false );
		openCloseServer.setCursor( new Cursor( Cursor.HAND_CURSOR ) );
		openCloseServer.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int fs = openCloseServer.getHeight() * 5 / 9;

				openCloseServer.setFont( new Font( "맑은 고딕", Font.BOLD, fs ) );
			}
		});

		openCloseServer.addMouseListener( new MouseAdapter() {

			@Override
			public void mouseEntered( MouseEvent ev ) {

				openCloseServer.setBackground( new Color( 210, 210, 150 ) );
			}

			@Override
			public void mouseExited( MouseEvent ev ) {

				openCloseServer.setBackground( new Color( 180, 180, 180 ) );
			}

			@Override
			public void mousePressed( MouseEvent ev ) {

				if( openCloseServerListener != null ) {
					openCloseServerListener.action();
				}
			}
		});

		clearLog = new JLabel( "로그 지우기" );
		clearLog.setHorizontalAlignment( JLabel.CENTER );
		clearLog.setOpaque( true );
		clearLog.setBackground( new Color( 180, 180, 180 ) );
		clearLog.setVisible( false );
		clearLog.setCursor( new Cursor( Cursor.HAND_CURSOR ) );
		clearLog.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int fs = clearLog.getHeight() * 5 / 9;

				clearLog.setFont( new Font( "맑은 고딕", Font.BOLD, fs ) );
			}
		});

		clearLog.addMouseListener( new MouseAdapter() {

			@Override
			public void mouseEntered( MouseEvent ev ) {

				clearLog.setBackground( new Color( 210, 210, 150 ) );
			}

			@Override
			public void mouseExited( MouseEvent ev ) {

				clearLog.setBackground( new Color( 180, 180, 180 ) );
			}

			@Override
			public void mousePressed( MouseEvent ev ) {

				if( clearLogListener != null ) {
					clearLogListener.action();
				}
			}
		});

		gameSpeed = new JLabel( "게임 속도" );
		gameSpeed.setHorizontalAlignment( JLabel.CENTER );
		gameSpeed.setOpaque( true );
		gameSpeed.setBackground( new Color( 180, 180, 180 ) );
		gameSpeed.setVisible( false );
		gameSpeed.setCursor( new Cursor( Cursor.HAND_CURSOR ) );
		gameSpeed.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int fs = gameSpeed.getHeight() * 5 / 9;

				gameSpeed.setFont( new Font( "맑은 고딕", Font.BOLD, fs ) );
			}
		});

		gameSpeed.addMouseListener( new MouseAdapter() {

			@Override
			public void mouseEntered( MouseEvent ev ) {

				gameSpeed.setBackground( new Color( 210, 210, 150 ) );
			}

			@Override
			public void mouseExited( MouseEvent ev ) {

				gameSpeed.setBackground( new Color( 180, 180, 180 ) );
			}

			@Override
			public void mousePressed( MouseEvent ev ) {

				if( gameSpeedListener != null ) {
					gameSpeedListener.action();
				}
			}
		});

		this.add( openCloseServer );
		this.add( clearLog );
		this.add( gameSpeed );

		switchScreen = new JLabel( "화면" );
		switchScreen.setHorizontalAlignment( JLabel.CENTER );
		switchScreen.setOpaque( true );
		switchScreen.setBackground( new Color( 180, 180, 180 ) );
		switchScreen.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int fs = switchScreen.getHeight() * 5 / 9;

				switchScreen.setFont( new Font( "맑은 고딕", Font.BOLD, fs ) );
			}
		});

		switchScreen.addMouseListener( new MouseAdapter() {

			@Override
			public void mouseEntered( MouseEvent ev ) {

				switchScreen.setBackground( new Color( 210, 210, 150 ) );
				switchScreen.setCursor( new Cursor( Cursor.HAND_CURSOR ) );
			}

			@Override
			public void mouseExited( MouseEvent ev ) {

				switchScreen.setBackground( new Color( 180, 180, 180 ) );
				switchScreen.setCursor( new Cursor( Cursor.DEFAULT_CURSOR ) );
			}

			@Override
			public void mousePressed( MouseEvent ev ) {

				if( switchScreenListener != null ) {
					switchScreenListener.action();
				}
			}
		});

		this.add( switchScreen );

		clickPlayerListener = new VegasListener[ VegasFrame.NUM_PLAYER_SLOTS ];

		this.setOpaque( false );
		this.setLayout( new LayoutManager() {

			@Override
			public void addLayoutComponent( String name, Component comp ) {}

			@Override
			public void removeLayoutComponent( Component comp ) {}

			@Override
			public Dimension preferredLayoutSize( Container parent ) { return null; }

			@Override
			public Dimension minimumLayoutSize( Container parent ) { return null; }

			@Override
			public void layoutContainer( Container parent ) {

				int pw = parent.getWidth();
				int ph = parent.getHeight();

				int mw = pw / 180;
				int mh = ph / 20;

				int w = ph - mh;
				int h = ( ph - mh ) / 2;
				int r = ( ph - mh ) % 2;
				int x = pw - w;
				int y = 0;

				roundLabel.setBounds( x, y, w, h );

				x = 0;
				w = pw - w - mw;

				if( banConfirmPanelOn ) {
					banConfirmPanel.setBounds( x, y, w, h );
					resultPanel.setBounds( x, y, 0, 0 );
				}
				else {
					banConfirmPanel.setBounds( x, y, 0, 0 );
					resultPanel.setBounds( x, y, w, h );
				}

				w = ph - mh;
				h = ( ph - mh ) / 2;
				x = pw - w;
				y = h + mh;

				switchScreen.setBounds( x, y, w, h + r );

				x = 0;
				y = h + mh;
				h = h + r;
				w = ( pw - ph + mh - 4 * mw ) / 4;
				r = ( pw - ph + mh - 4 * mw ) % 4;

				// 고정 인덱스
				playerLabels[ 0 ].setBounds( x, y, w, h );
				x += w + mw;
				playerLabels[ 1 ].setBounds( x, y, w, h );
				x += w + mw;
				playerLabels[ 2 ].setBounds( x, y, w, h );
				x += w + mw;
				playerLabels[ 3 ].setBounds( x, y, w + r, h );

				int ww = ( pw - ph + mh - mw ) - 4 * mw;
				int w1 = ww * 2 / 9;
				int w2 = ww * 2 / 15;
				int w3 = ww * 2 / 9;
				int w4 = ww * 2 / 9;
				int w5 = ww - w1 - w2 - w3 - w4;

				x = 0;

				ipField.setBounds( x, y, w1, h );
				x += w1 + mw;
				portField.setBounds( x, y, w2, h );
				x += w2 + mw;
				openCloseServer.setBounds( x, y, w3, h );
				x += w3 + mw;
				clearLog.setBounds( x, y, w4, h );
				x += w4 + mw;
				gameSpeed.setBounds( x, y, w5, h );
			}
		});
	}
}
