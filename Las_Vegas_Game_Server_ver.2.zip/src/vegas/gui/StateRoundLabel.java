
package vegas.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class StateRoundLabel extends JLabel {

	private static final long serialVersionUID = -561218161286861638L;

	private final StateRoundLabel ref;

	StateRoundLabel() {

		ref = this;

		this.setHorizontalAlignment( JLabel.CENTER );
		this.setBackground( VegasFrame.PANEL_BACKGROUND );
		this.setForeground( Color.WHITE );
		this.setOpaque( true );
		this.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int fs = ref.getHeight() * 3 / 5;

				ref.setFont( new Font( "맑은 고딕", Font.BOLD, fs ) );
			}
		});
	}
}
