
package vegas.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class BanConfirmPanel extends JPanel {

	private static final long serialVersionUID = 5436005193519569316L;

	VegasListener[] banPlayerListener;

	int playerNum;

	final JLabel lbl;

	final JLabel yesBtn;

	final JLabel noBtn;

	BanConfirmPanel() {

		banPlayerListener = new VegasListener[ VegasFrame.NUM_PLAYER_SLOTS - 1 ];

		lbl = new JLabel();
		lbl.setForeground( Color.YELLOW );
		lbl.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int h = lbl.getHeight();

				lbl.setFont( new Font( "맑은 고딕", Font.BOLD, h * 3 / 7 ) );
				lbl.setBorder( new EmptyBorder( 0, h / 3, 0, h / 3 ) );
			}
		});

		yesBtn = new JLabel( "예" );
		yesBtn.setHorizontalAlignment( JLabel.CENTER );
		yesBtn.setForeground( Color.WHITE );
		yesBtn.setOpaque( true );
		yesBtn.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int h = yesBtn.getHeight();

				yesBtn.setFont( new Font( "맑은 고딕", Font.BOLD, h * 4 / 7 ) );
				yesBtn.setBorder( new EmptyBorder( 0, h / 3, 0, h / 3 ) );
			}
		});

		yesBtn.setCursor( new Cursor( Cursor.HAND_CURSOR ) );
		yesBtn.setBackground( new Color( 0, 150, 0 ) );
		yesBtn.addMouseListener( new MouseAdapter() {

			private final Color backNormal  = new Color( 0, 150, 0 );
			private final Color backHover   = new Color( 0, 190, 0 );
			private final Color backPressed = new Color( 0, 110, 0 );

			@Override
			public void mouseExited( MouseEvent ev ) {

				yesBtn.setBackground( backNormal );
			}

			@Override
			public void mouseEntered( MouseEvent ev ) {

				yesBtn.setBackground( backHover );
			}

			@Override
			public void mousePressed( MouseEvent ev ) {

				yesBtn.setBackground( backPressed );
			}

			@Override
			public void mouseReleased( MouseEvent ev ) {

				int x = ev.getX();
				int y = ev.getY();

				int pw = yesBtn.getWidth();
				int ph = yesBtn.getHeight();

				if( x < 0 || pw <= x || y < 0 || ph <= y ) {
					yesBtn.setBackground( backNormal );
				}
				else {
					yesBtn.setBackground( backHover );
					if( banPlayerListener[ playerNum ] != null ) {
						banPlayerListener[ playerNum ].action();
					}
				}
			}
		});

		noBtn = new JLabel( "아니오" );
		noBtn.setHorizontalAlignment( JLabel.CENTER );
		noBtn.setForeground( Color.WHITE );
		noBtn.setOpaque( true );
		noBtn.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int h = noBtn.getHeight();

				noBtn.setFont( new Font( "맑은 고딕", Font.BOLD, h * 4 / 7 ) );
				noBtn.setBorder( new EmptyBorder( 0, h / 3, 0, h / 3 ) );
			}
		});

		noBtn.setCursor( new Cursor( Cursor.HAND_CURSOR ) );
		noBtn.setBackground( new Color( 150, 0, 0 ) );
		noBtn.addMouseListener( new MouseAdapter() {

			private final Color backNormal  = new Color( 150, 0, 0 );
			private final Color backHover   = new Color( 190, 0, 0 );
			private final Color backPressed = new Color( 110, 0, 0 );

			@Override
			public void mouseExited( MouseEvent ev ) {

				noBtn.setBackground( backNormal );
			}

			@Override
			public void mouseEntered( MouseEvent ev ) {

				noBtn.setBackground( backHover );
			}

			@Override
			public void mousePressed( MouseEvent ev ) {

				noBtn.setBackground( backPressed );
			}

			@Override
			public void mouseReleased( MouseEvent ev ) {

				int x = ev.getX();
				int y = ev.getY();

				int pw = noBtn.getWidth();
				int ph = noBtn.getHeight();

				if( x < 0 || pw <= x || y < 0 || ph <= y ) {
					noBtn.setBackground( backNormal );
				}
				else {
					noBtn.setBackground( backHover );
					StatePanel statePanel = ( StatePanel )ev
							.getComponent().getParent().getParent();

					statePanel.banConfirmPanelOn = false;
					statePanel.revalidate();
					statePanel.repaint();
				}
			}
		});

		this.add( lbl );
		this.add( yesBtn );
		this.add( noBtn );
		this.setBackground( VegasFrame.PANEL_BACKGROUND );
		this.setLayout( new LayoutManager() {

			@Override
			public void addLayoutComponent( String name, Component comp ) {}

			@Override
			public void removeLayoutComponent( Component comp ) {}

			@Override
			public Dimension preferredLayoutSize( Container parent ) { return null; }

			@Override
			public Dimension minimumLayoutSize( Container parent ) { return null; }

			@Override
			public void layoutContainer( Container parent ) {

				int pw = parent.getWidth();
				int ph = parent.getHeight();

				int x1 = 0;
				int y1 = 0;
				int w1 = pw * 4 / 5;
				int h1 = ph;

				lbl.setBounds( x1, y1, w1, h1 );

				int mw = pw / 110;
				int mh = ph / 6;
				int wr = pw - w1 - 3 * mw;

				int x2 = w1 + mw;
				int y2 = mh;
				int w2 = wr * 2 / 5;
				int h2 = ph - 2 * mh;

				yesBtn.setBounds( x2, y2, w2, h2 );

				int x3 = x2 + w2 + mw;
				int y3 = y2;
				int w3 = wr - w2;
				int h3 = h2;

				noBtn.setBounds( x3, y3, w3, h3 );
			}
		});
	}
}
