
package vegas.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.*;

class LogPanel extends JScrollPane {

	// NoTextSelectionCaret
	// 텍스트영역 선택기능을 없애주는 클래스

	private class NoTextSelectionCaret extends DefaultCaret {

		private static final long serialVersionUID = 1721773670440869970L;

		private NoTextSelectionCaret( JTextComponent textComponent ) {

			setBlinkRate( textComponent.getCaret().getBlinkRate() );
			textComponent.setHighlighter( null );
		}

		@Override
		public int getMark() {

			return getDot();
		}
	}

	// SmartVerticalScroller
	// 수직스크롤러에 자동스크롤 기능을 추가해주는 클래스

	private class SmartVerticalScroller implements AdjustmentListener {

		private final JScrollBar verBar;

		private boolean adjVerBar = true;

		private int prevVal = -1;
		private int prevMax = -1;

		SmartVerticalScroller( JScrollPane scrlPane ) {

			verBar = scrlPane.getVerticalScrollBar();
			verBar.addAdjustmentListener( this );

			Component view = scrlPane.getViewport().getView();
			if( view instanceof JTextComponent ) {
				JTextComponent txtComp = ( JTextComponent )view;
				DefaultCaret caret = ( DefaultCaret )txtComp.getCaret();
				caret.setUpdatePolicy( DefaultCaret.NEVER_UPDATE );
			}
		}

		public final void adjustmentValueChanged( AdjustmentEvent ev ) {

			SwingUtilities.invokeLater( new Runnable() {

				@Override
				public void run() {
					checkScrollBar( ev );
				}
			});
		}

		private void checkScrollBar( AdjustmentEvent ev ) {

			BoundedRangeModel listModel = verBar.getModel();
			int val = listModel.getValue();
			int ext = listModel.getExtent();
			int max = listModel.getMaximum();

			boolean valChanged = prevVal != val;
			boolean maxChanged = prevMax != max;
			if( valChanged && !maxChanged ) adjVerBar = val + ext >= max;

			if( adjVerBar ) {

				verBar.removeAdjustmentListener( this );
				val = max - ext;
				verBar.setValue( val );
				verBar.addAdjustmentListener( this );
			}

			prevVal = val;
			prevMax = max;
		}
	}

	// IndecButton
	// 스크롤러의 증감버튼

	private class IndecButton extends JButton {

		private static final long serialVersionUID = -8248114587854219084L;

		private final IndecButton ref;

		private final Image img;

		IndecButton( String path ) {

			ref = this;

			img = VegasResource.loadImage( path );

			ref.setBorder( null );
			ref.setFocusable( false );
			ref.setContentAreaFilled( false );
			ref.setBackground( new Color( 150, 150, 150 ) );
		}

		@Override
		public void paintComponent( Graphics g ) {

			super.paintComponent( g );

			int tw = ref.getWidth();
			int th = ref.getHeight();

			g.setColor( ref.getBackground() );
			g.fillRect( 0, 0, tw, th );

			int imgW = tw / 2;
			int imgH = th / 2;

			Image imgTmp = img.getScaledInstance( imgW, imgH, Image.SCALE_SMOOTH );
			g.drawImage( imgTmp, ( tw - imgW ) / 2, ( th - imgH ) / 2, imgW, imgH, null );
		}
	}

	// ScrollBarBlackUI
	// 스크롤바 블랙테마

	private class ScrollBarBlackUI extends BasicScrollBarUI {

		@Override
		protected void paintTrack( Graphics g, JComponent c, Rectangle trackBounds ) {

			int x = trackBounds.x;
			int y = trackBounds.y;
			int w = trackBounds.width;
			int h = trackBounds.height;

			g.setColor( new Color( 150, 150, 150 ) );
			g.fillRect( x, y, w, h );
		}

		@Override
		protected void paintThumb( Graphics g, JComponent c, Rectangle thumbBounds ) {

			int x = thumbBounds.x;
			int y = thumbBounds.y;
			int w = thumbBounds.width;
			int h = thumbBounds.height;

			g.setColor( new Color( 50, 50, 50 ) );
			g.fillRect( x, y, w, h );
		}

		@Override
		protected JButton createDecreaseButton( int orientation ) {

			if( orientation == 1 )
				// VERTICAL
				return new IndecButton( "vegas/gui/res/img_tri_up.png" );
			else
				// HORIZONTAL
				return new IndecButton( "vegas/gui/res/img_tri_left.png" );
		}

		@Override
		protected JButton createIncreaseButton( int orientation ) {

			if( orientation == 5 )
				// VERTICAL
				return new IndecButton( "vegas/gui/res/img_tri_down.png" );
			else
				// HORIZONTAL
				return new IndecButton( "vegas/gui/res/img_tri_right.png" );
		}
	}



	/******************************************************************************/
	/******************************************************************************/



	private static final long serialVersionUID = -976308319070817593L;

	private final LogPanel ref;

	final JTextArea txtArea = new JTextArea();

	final JScrollBar vBar;
	final JScrollBar hBar;

	LogPanel() {

		ref = this;

		txtArea.setEditable( false );
		txtArea.setFocusable( false );
		txtArea.setBorder( new EmptyBorder( 10, 10, 10, 10 ) );
		txtArea.setBackground( new Color( 100, 100, 100 ) );
		txtArea.setForeground( new Color( 255, 255, 255 ) );
		txtArea.setCaret( new NoTextSelectionCaret( txtArea ) );
		txtArea.setFont( new Font( "Consolas", Font.BOLD, 14 ) );

		this.setViewportView( txtArea );
		this.setBorder( BorderFactory.createEmptyBorder() );

		JPanel corner1 = new JPanel();
		corner1.setBackground( new Color( 130, 130, 130 ) );
		this.setCorner( JScrollPane.UPPER_RIGHT_CORNER, corner1 );

		JPanel corner2 = new JPanel();
		corner2.setBackground( new Color( 130, 130, 130 ) );
		this.setCorner( JScrollPane.LOWER_RIGHT_CORNER, corner2 );

		vBar = this.getVerticalScrollBar();
		vBar.setUnitIncrement( 70 );
		vBar.setBlockIncrement( 70 );
		vBar.setUI( new ScrollBarBlackUI() );
		this.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS );

		hBar = this.getHorizontalScrollBar();
		hBar.setUnitIncrement( 70 );
		hBar.setBlockIncrement( 70 );
		hBar.setUI( new ScrollBarBlackUI() );
		this.setHorizontalScrollBarPolicy( JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS );

		new SmartVerticalScroller( this );

		this.addComponentListener( new ComponentAdapter() {

			@Override
			public void componentResized( ComponentEvent ev ) {

				int w = ref.getWidth() / 50;
				int h = ref.getHeight() / 30;

				txtArea.setFont( new Font( "Consolas", Font.BOLD, h ) );
				txtArea.setBorder( new EmptyBorder( h / 2, w / 2, h / 2, w / 2 ) );

				vBar.setPreferredSize( new Dimension( w, 99999 ) );
				vBar.getComponent( 0 ).setPreferredSize( new Dimension( w, w ) );
				vBar.getComponent( 1 ).setPreferredSize( new Dimension( w, w ) );

				hBar.setPreferredSize( new Dimension( 99999, h ) );
				hBar.getComponent( 0 ).setPreferredSize( new Dimension( h, h ) );
				hBar.getComponent( 1 ).setPreferredSize( new Dimension( h, h ) );
			}
		});
	}
}
