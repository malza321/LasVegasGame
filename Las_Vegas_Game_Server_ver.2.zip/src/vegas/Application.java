
package vegas;

import java.io.*;
import java.net.*;
import java.nio.channels.*;
import vegas.gui.*;
import vegas.ev.lis.*;

public class Application {

	public static Database db = null;

	public static final boolean PIPE = false;

	public static void main( String[] args ) {

		// ## 초기화 순서
		// 1. 싱글 인스턴스 확인
		// 2. 파이핑 stderr
		// 3. 안티얼라이어싱 ON ( 글자 계단현상 방지 )
		// 4. DB 생성
		// 5. 윈도우 초기화 및 보이기

		try {
			@SuppressWarnings( "resource" )
			RandomAccessFile file = new RandomAccessFile( "instance", "rw" );
			FileChannel channel = file.getChannel();
			if( channel.tryLock() == null ) { throw new Exception( "lock failed" ); }
		}
		catch( Exception ex ) { System.exit( 1 ); }

		if( PIPE ) {
			try { System.setErr( new PrintStream( "stderr.log" ) ); }
			catch( Exception ex ) { System.exit( 1 ); }
		}

		System.setProperty( "awt.useSystemAAFontSettings", "on" );
		System.setProperty( "swing.aatext", "true" );

		db = new Database();
		db.speed = 3;
		VegasFrame frame = db.frame = new VegasFrame();


		/*============================================================*/


		frame.setSwitchScreenListener( new SwitchScreenListener() );
		frame.setOpenCloseServerListener( new OpenCloseServerListener() );
		frame.setClearLogListener( new ClearLogListener() );
		frame.setGameSpeedListener( new GameSpeedListener() );

		for( int pn = VegasFrame.PLAYER_1; pn <= VegasFrame.PLAYER_4; pn ++ ) {

			frame.setClickPlayerListener( pn, new ClickPlayerListener( pn ) );
			frame.setBanPlayerListener( pn, new BanPlayerListener( pn ) );
		}

		frame.removeAllMoneys();
		frame.removeAllBattings();
		frame.removeAllRollResults();
		frame.removeAllPlayerDices();
		frame.removeAllPlayerHighlights();
		frame.setRound( 0, 0 );

		frame.setMessage( "화면 버튼을 클릭하고 서버를 열어주세요." );
		frame.showMessage();

		frame.logClearLines();
		frame.logNewLine( "LAS VEGAS GAME server" );
		frame.logNewLine( "lsv server app - ver. 1.1" );
		frame.logNewLine( "created by js jeong, jihyeon jo, and prof. seol" );
		frame.logNewLine( "in DICE, KOREA TECH" );
		frame.logNewLine( "===============================================" );
		frame.logNewLine( "#### app start success" );

		try {
			InetAddress adrs = InetAddress.getLocalHost();
			frame.setAddressFields( adrs.getHostAddress(), "33333" );
		}
		catch( Exception ex ) {
			ex.printStackTrace();
			frame.setAddressFields( "127.0.0.1", "33333" );
		}

		frame.setScreen( false );
		frame.setVisible( true );
	}
}
