
package vegas;

import java.net.*;
import vegas.ev.*;

public class ClientAccepter extends Thread {

	@Override
	public void run() {

		Database db = Application.db;

		while( true ) {

			try {
				Socket socket = db.listener.accept();
				sleep( 0 );
				if( db.gameStarted ) {
					socket.close();
					continue;
				}
				EventProcessor.process( EventType.ACCEPT_CLIENT, socket );
			}

			catch( Exception ex ) {
				EventProcessor.process( EventType.CLOSE_SERVER, null );
				return;
			}
		}
	}
}
