
package vegas;

import java.io.*;
import java.net.*;
import vegas.gui.*;

public class Database {

	// 중립주사위 사용여부
	// 사용하지 않기로 결정 ( 2017학년도 1학기 )
	public static final boolean USE_NEUTRALITY = false;

	public static final int NUM_CASINOS     = 6;
	public static final int MAX_NUM_MONEYS  = 5;
	public static final int MAX_NUM_CLIENTS = 4; // 중립 미포함
	public static final int MAX_NUM_PLAYERS = 5; // 중립 포함

	public static final int WAIT_NAME  = 0; // 이름을 주지 않은 상태
	public static final int WAIT_START = 1; // 시작을 대기하는 상태
	public static final int WAIT_TURN  = 2; // 차례가 아닌 상태
	public static final int WAIT_ROLL  = 3; // 차례이며, 주사위를 던져야하는 상태
	public static final int WAIT_BAT   = 4; // 차례이며, 배팅을 해야하는 상태

	public static final int LAST_ROUND = 2;

	public static final int NUM_OWN_DICES = 8;
	public static final int NUM_NEU_DICES = 2;
	public static final int MAX_NUM_DICES = NUM_OWN_DICES + NUM_NEU_DICES;

	public static final int MIN_TOTAL_MONEY = 50000;

	public static final int[] AVAILABLE_MONEYS = {

			10000,
			20000,
			30000,
			40000,
			50000,
			60000,
			70000,
			80000,
			90000
	};

	public static final String EMPTY_NAME = "------";

	public static final String DEFAULT_NAME = "??????";

	public static final String BOT_HEADER = "[BOT] ";

	public static final String[] BOT_NAMES = {

			"HAL",
			"SkyNet",
			"Matrix",
			"AlphaGo"
	};

	public static final int DIFF_EASY   = 0;
	public static final int DIFF_NORMAL = 1;
	public static final int DIFF_HARD   = 2;


	/***************************************************************/
	/***************************************************************/


	public static final int PLAYER_1 = 0;
	public static final int PLAYER_2 = 1;
	public static final int PLAYER_3 = 2;
	public static final int PLAYER_4 = 3;
	public static final int PLAYER_5 = 4;

	public static final int CASINO_1 = 0;
	public static final int CASINO_2 = 1;
	public static final int CASINO_3 = 2;
	public static final int CASINO_4 = 3;
	public static final int CASINO_5 = 4;
	public static final int CASINO_6 = 5;


	/***************************************************************/
	/***************************************************************/


	public volatile VegasFrame frame;

	public volatile InetAddress ipAdrs;
	public volatile int         portNum;
	public volatile int         numClients;
	public volatile int         numNames;

	public volatile ServerSocket   listener;
	public volatile ClientAccepter accepter;

	public volatile ClientThread[]   threads = new ClientThread  [ MAX_NUM_CLIENTS ];
	public volatile Socket[]         sockets = new Socket        [ MAX_NUM_CLIENTS ];
	public volatile BufferedReader[] readers = new BufferedReader[ MAX_NUM_CLIENTS ];
	public volatile BufferedWriter[] writers = new BufferedWriter[ MAX_NUM_CLIENTS ];

	public volatile boolean[] isPlayerBots = new boolean[ MAX_NUM_CLIENTS ];
	public volatile String[]  playerNames  = new String [ MAX_NUM_CLIENTS ];
	public volatile int[]     playerDiffs  = new int    [ MAX_NUM_CLIENTS ];
	public volatile int[]     playerStates = new int    [ MAX_NUM_CLIENTS ];
	public volatile String[]  lineBufs     = new String [ MAX_NUM_CLIENTS ];

	public volatile boolean serverOpened;
	public volatile boolean gameStarted;

	// 상단 : 주로 게임 전 변수
	// 하단 : 주로 게임 후 변수
	
	public volatile int speed;

	public volatile int curRound;
	public volatile int curTurn;

	public volatile int[] numOwnDices = new int[ MAX_NUM_CLIENTS ];
	public volatile int[] numNeuDices = new int[ MAX_NUM_CLIENTS ];
	public volatile int[] rollResults = new int[ MAX_NUM_DICES   ];

	public volatile int bat;

	public volatile int[][] moneyStates      = new int[ NUM_CASINOS ][ MAX_NUM_MONEYS  ];
	public volatile int[][] battingStates    = new int[ NUM_CASINOS ][ MAX_NUM_PLAYERS ];
	public volatile int[][] casinoEarnMoneys = new int[ NUM_CASINOS ][ MAX_NUM_PLAYERS ];
	public volatile int[][] earnMoneys       = new int[ LAST_ROUND  ][ MAX_NUM_PLAYERS ];
}
